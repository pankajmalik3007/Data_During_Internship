﻿using CascadingCRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Query.Internal;

namespace CascadingCRUD.Controllers
{
    public class CascadingController : Controller
    {
        private readonly MainDBContext  _dbContext;
        public CascadingController(MainDBContext dbContext)
        { 
            _dbContext = dbContext;
        }
        public JsonResult Country()
        {
            var cou = _dbContext.countries.ToList();    
            return new JsonResult(cou);
        }
        public JsonResult State(int id)
        {
            var state = _dbContext.states.Where(e => e.CountryID == id).ToList();
            return new JsonResult(state);
        }
        public JsonResult City(int id)
        {
            var city = _dbContext.citys.Where(d=>d.StateID== id).ToList();
            return new JsonResult(city);
        }

        public IActionResult CascadeDropDown()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
