﻿using System.ComponentModel.DataAnnotations;

namespace CascadingCRUD.Models.Cascade
{
    public class State
    {
       
        public int StateID { get; set; }
        public string StateName { get; set; }
        public int CountryID { get; set; }
        public Country Country { get; set; }    
        public IList<City> City { get; set; }
    }
}
