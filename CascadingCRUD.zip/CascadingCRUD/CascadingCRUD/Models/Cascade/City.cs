﻿using System.ComponentModel.DataAnnotations;

namespace CascadingCRUD.Models.Cascade
{
    public class City
    {
     
        public int CityID { get;set; }
        public string CityName { get;set; } 
        public int StateID { get;set; }
        public State State { get;set; }
    }
}
