﻿using System.ComponentModel.DataAnnotations;

namespace CascadingCRUD.Models.Cascade
{
    public class Country
    {
        
        public int CountryID { get;set; }
        public string CountryName { get; set; }
       public IList<State> states { get; set; }
    }
}
