﻿using System.ComponentModel.DataAnnotations;

namespace CascadingCRUD.Models.ViewModel
{
    public class Employee
    {
        [Key]

        public int Id { get; set; }
       public string Name { get; set; }
    }
}
