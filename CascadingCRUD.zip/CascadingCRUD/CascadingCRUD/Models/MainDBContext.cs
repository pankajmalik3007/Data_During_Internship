﻿using CascadingCRUD.Models.Cascade;
using CascadingCRUD.Models.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace CascadingCRUD.Models
{
    public class MainDBContext : DbContext
    {
        public MainDBContext(DbContextOptions options):base(options     ) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Country> countries { get; set; }
        public DbSet<State> states { get; set; }
        public DbSet<City> citys { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<State>()
                .HasOne(d => d.Country)
                .WithMany(d => d.states)
                .HasForeignKey(s => s.CountryID)
                .IsRequired();

            modelBuilder.Entity<City>()
                .HasOne(d => d.State)
                .WithMany(d => d.City)
                .HasForeignKey(d => d.StateID)
                .IsRequired();
                
        }
    }
}
