﻿using System;
using System.Reflection;

namespace BugFixApplication
{
    //a custom attribute BugFix to be assigned to a class and its members
    [AttributeUsage(
       AttributeTargets.Class |
       AttributeTargets.Constructor |
       AttributeTargets.Field |
       AttributeTargets.Method |
       AttributeTargets.Property,
       AllowMultiple = true)]

    public class StudentInfo : System.Attribute
    {
        private int Std_No;
        private string Std_Name;
        private string Std_Addr;
        public string message;

        public StudentInfo(int no, string name, string addr)
        {
            this.Std_No = no;
            this.Std_Name = name;
            this.Std_Addr = addr;
        }
        public int No
        {
            get
            {
                return Std_No;
            }
        }
        public string Name
        {
            get
            {
                return Std_Name;
            }
        }
        public string Addr
        {
            get
            {
                return Std_Addr;
            }
        }
       /* public string Message
        {
            get
            {
                return message;
            }
            set
            {
                message = value;
            }
        }*/
    }
    [StudentInfo(1, "Pratik", "Yeola"  /*,Message = "Return type mismatch"*/)]
    [StudentInfo(2, "Pamkaj", "Vaijapur" /*, Message = "Unused variable"*/)]

    class Rectangle
    {
        //member variables
        protected double length;
        protected double width;

        public Rectangle(double l, double w)
        {
            length = l;
            width = w;
        }

        [StudentInfo(3, "Mayur", "Yeola" /*, Message = "Return type mismatch"*/)]
        public double GetArea()
        {
            return length * width;
        }

        [StudentInfo(4, "Pavan", "Kopagaon" /*,Message ="Return type missmatch"*/)]
        public void Display()
        {
            Console.WriteLine("Length: {0}", length);
            Console.WriteLine("Width: {0}", width);
            Console.WriteLine("Area: {0}", GetArea());
        }
    }//end class Rectangle

    class ExecuteRectangle
    {
        static void Main(string[] args)
        {
            Rectangle r = new Rectangle(4.5, 7.5);
            r.Display();
            Type type = typeof(Rectangle);

            //iterating through the attribtues of the Rectangle class
            foreach (Object attributes in type.GetCustomAttributes(false))
            {
                StudentInfo std = (StudentInfo)attributes;

                if (null != std)
                {
                    Console.WriteLine("Student roll no : {0}", std.No);
                    Console.WriteLine("Student Name: {0}", std.Name);
                    Console.WriteLine("Student Address: {0}", std.Addr);
                   //Console.WriteLine("Remarks: {0}", std.Message);
                }
            }

            //iterating through the method attribtues
            foreach (MethodInfo m in type.GetMethods())
            {

                foreach (Attribute a in m.GetCustomAttributes(true))
                {
                    StudentInfo std = (StudentInfo)a;

                    if (null != std)
                    {
                        Console.WriteLine("Stdudent no : {0}, for Method: {1}", std.No, m.Name);
                        Console.WriteLine("Student name : {0}", std.Name);
                        Console.WriteLine("Student address : {0}", std.Addr);
                        //Console.WriteLine("Remarks: {0}", std.Message);
                    }
                }
            }
            Console.ReadLine();
        }
    }
}