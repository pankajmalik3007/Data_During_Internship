﻿using Domain.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RepositoryAndServices.Context;
using RepositoryAndServices.Services.Custom;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;
        private readonly MainDbContext _mainDbContext;

        public EmployeeController(IEmployeeService employeeService, MainDbContext mainDbContext)
        {
            _employeeService = employeeService;
            _mainDbContext = mainDbContext;
        }

        [Route("GetAllEmployee")]
        [HttpGet]
        public async Task<ActionResult<EmployeeViewModel>> GetAllEmployee()
        {
            var result = await _employeeService.GetAll();

            if (result == null)
                return BadRequest("No Records Found, Please Try Again After Adding them...!");

            return Ok(result);
        }


        [Route("GetById")]
        [HttpGet]
        public async Task<ActionResult<EmployeeViewModel>> GetById(int Id)
        {
            if (Id != null)
            {
                var res = await _employeeService.GetById(Id);
                if (res == null)

                    return BadRequest("Id Not Found");
                return Ok(res);
            }

            else
                return BadRequest("Please Enter Valid Id");
            
        }
        [Route("InsertEmployee")]
        [HttpPost]
        public async Task<IActionResult> InsertEmployee(EmployeeInsertModel userTypeInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _employeeService.Insert(userTypeInsertModel);
                if (result == true)
                    return Ok("Employee Inserted Successfully...!");
                else
                    return BadRequest("Something Went Wrong, UserType Is Not Inserted, Please Try After Sometime...!");
            }
            else
                return BadRequest("Invalid Employee Information, Please Provide Correct Details for UserType...!");
        }


        [Route("UpdateEmployee")]
        [HttpPut]
        public async Task<IActionResult> UpdateEmployee(EmployeeUpdateModel userTypeModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _employeeService.Update(userTypeModel);
                if (result == true)
                    return Ok(userTypeModel);
                else
                    return BadRequest("Something went wrong, Please Try again later...!");
            }
            else
                return BadRequest("Invalid Employee Information, Please Provide Correct Details for UserType...!");
        }


        [Route("DeleteEmployee")]
        [HttpDelete]

        public async Task<IActionResult> DeleteEmployee(int Id)
        {
            var result = await _employeeService.Delete(Id);
            if (result == true)
                return Ok("Employee Deleted Successfully...!");
            else
                return BadRequest("Employee is not deleted, Please Try again later...!");

        }

        [Route("GetSallaryByName")]
        [HttpGet]

        public async Task<IActionResult> GetSallaryByName(int id)
        {
            var student = await _mainDbContext.Salaries.Where(e => e.Emp_Id == id).Select(e => e.SalAmt).ToListAsync();
            if(student == null)
            {
                return BadRequest("InValid");
            }

            return Ok(student);
        }
    }
}
