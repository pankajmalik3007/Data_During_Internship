﻿using Domain.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepositoryAndServices.Services.Custom;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentService _departmentService;
        public DepartmentController(IDepartmentService departmentService)
        {
            _departmentService = departmentService;
        }

        [Route("GetAllDepartment")]
        [HttpGet]
        public async Task<ActionResult<DepartmentViewModel>> GetAllDepartment()
        {
            var result = await _departmentService.GetAll();

            if (result == null)
                return BadRequest("No Records Found, Please Try Again After Adding them...!");

            return Ok(result);
        }

        [Route("GetById")]
        [HttpGet]
        public async Task<ActionResult<DepartmentViewModel>> GetById(int Id)
        {
            if (Id != null)
            {
                var res = await _departmentService.GetById(Id);
                if (res == null)

                    return BadRequest("Id Not Found");
                return Ok(res);
            }

            else
                return BadRequest("Please Enter Valid Id");

        }

        [Route("InsertDepartment")]
        [HttpPost]
        public async Task<IActionResult> InsertDepartment(DepartmentInsertModel userTypeInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _departmentService.Insert(userTypeInsertModel);
                if (result == true)
                    return Ok("Department Inserted Successfully...!");
                else
                    return BadRequest("Something Went Wrong, UserType Is Not Inserted, Please Try After Sometime...!");
            }
            else
                return BadRequest("Invalid Department Information, Please Provide Correct Details for UserType...!");
        }

        [Route("UpdateDepartment")]
        [HttpPut]
        public async Task<IActionResult> UpdateEmployee(DepartmentUpdateModel userTypeModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _departmentService.Update(userTypeModel);
                if (result == true)
                    return Ok(userTypeModel);
                else
                    return BadRequest("Something went wrong, Please Try again later...!");
            }
            else
                return BadRequest("Invalid Department Information, Please Provide Correct Details for UserType...!");
        }

        [Route("DeleteDepartment")]
        [HttpDelete]

        public async Task<IActionResult> DeleteDepartment(int Id)
        {
            var result = await _departmentService.Delete(Id);
            if (result == true)
                return Ok("Department Deleted Successfully...!");
            else
                return BadRequest("Department is not deleted, Please Try again later...!");

        }
    }
}
