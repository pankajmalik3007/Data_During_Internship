﻿using Domain.Models;
using Domain.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepositoryAndServices.Repository;
using RepositoryAndServices.Services.Custom;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SallaryController : ControllerBase
    {
        private readonly IRepository<Salary> _sallary;
        private readonly ISallaryService _sallaryService;
        private readonly IEmployeeService _employeeService;
        private readonly IDepartmentService _departmentService;
        private readonly ILogger<Salary> _logger;

        public SallaryController(ISallaryService sallaryService, ILogger<Salary> logger, IRepository<Salary> sallary, IEmployeeService employeeService, IDepartmentService departmentService)
        {
            _sallaryService = sallaryService;
            _sallary = sallary;
            _employeeService = employeeService;
            _departmentService = departmentService;
            _logger = logger;
        }

        [Route("GetSallaryById")]
        [HttpGet]

        public async Task<ActionResult<SalaryViewModel>> GetById(int Id)
        {
            if (Id != null)
            {
                var res = await _sallary.Get(Id);
                if (res == null)

                    return BadRequest("Id Not Found");
                return Ok(res);
            }

            else
                return BadRequest("Please Enter Valid Id");

        }




        [HttpPost(nameof(Insert))]
        public async Task<IActionResult> Insert(SalaryInsertModel SalaryInsertModel)
        {
            if (ModelState.IsValid)
            {
                Employee employee = await _employeeService.Find(x => x.Id == SalaryInsertModel.Emp_Id);
                if (employee != null)
                {
                    Department department = await _departmentService.Find(x => x.Id == SalaryInsertModel.Dep_Id);
                    if (department != null)
                    {

                        var result = await _sallaryService.Insert(SalaryInsertModel);
                        if (result == true)
                        {

                            return Ok("data Inserted Successfully.....!");
                        }
                        else
                        {

                            return BadRequest("Something Went Wrong.....!");
                        }
                    }
                    else
                        return BadRequest("Course Id is not found ");
                }
                else
                    return BadRequest("Course Id is not found ");

            }
            else
            {
                return BadRequest("Model State Is not valid...!");
            }
        }

        [HttpPut(nameof(Update))]
        public async Task<IActionResult> Update(SalaryUpdateModel SalaryUpdateModel)
        {
            if (ModelState.IsValid)
            {

                var result = await _sallaryService.Update(SalaryUpdateModel);
                if (result == true)
                {

                    return Ok("Data Updated Successfully ...... !");
                }
                else
                {

                    return BadRequest("Something went Wrong...... !");
                }
            }
            else
            {
                return BadRequest("ModelState is Not valid....!");
            }
        }


        [HttpDelete(nameof(Delete))]
        public async Task<IActionResult> Delete(int id)
        {
            if (id != null)
            {

                var result = await _sallaryService.Delete(id)
;
                if (result == true)
                {

                    return Ok("Data Deleted Successfully....!");
                }
                else
                {

                    return BadRequest("Somthing Went Wrong......!");
                }
            }
            else
            {
                return BadRequest("Id was not Found");
            }
        }

    }
}
