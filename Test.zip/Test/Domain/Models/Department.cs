﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class Department : BaseEntity
    {
        public string Dep_Id { get; set; }
        public string Dep_Name { get; set; }

       public ICollection<Salary> Salaries { get; set; }
    }
}
