﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ViewModel
{
    public class EmployeeViewModel
    {
        public int Id { get; set; }
        public string Emp_Id { get; set; }

        public string Emp_Name { get; set; }

        public string Emp_Adress { get; set; }

        public string Email { get; set; }

    }

    public class EmployeeInsertModel
    {
        public string Emp_Name { get; set; }
        public string Emp_Id { get; set; }


        public string Emp_Adress { get; set; }

        public string Email { get; set; }
    }

    public class EmployeeUpdateModel : EmployeeViewModel
    {
        public int Id { get; set; }

    }
}
