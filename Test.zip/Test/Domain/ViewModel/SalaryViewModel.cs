﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ViewModel
{
    public class SalaryViewModel
    {
        public int Id { get; set; }
        public int Emp_Id { get; set; }
        public int Dep_Id { get; set; }
        public string SalAmt { get; set; }
    }

    public class SalaryInsertModel
    {
        public string SalAmt { get; set; }
        public int Emp_Id { get; set; }
        public int Dep_Id { get; set; }

    }

    public class SalaryUpdateModel : SalaryInsertModel
    {
        public int Id { get; set; }
    }
}
