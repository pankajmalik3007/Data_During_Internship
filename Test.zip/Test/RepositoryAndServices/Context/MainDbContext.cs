﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Context
{
    public class MainDbContext : DbContext
    {
        public MainDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }

        public DbSet<Salary> Salaries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Salary>()
                .HasOne(e => e.Employee)
                .WithMany(e => e.salaries)
                .HasForeignKey(e => e.Emp_Id)
                .IsRequired();


            modelBuilder.Entity<Salary>()
                .HasOne(e => e.Department)
                .WithMany(e => e.Salaries)
                .HasForeignKey(e => e.Dep_Id)
                .IsRequired();
        }
    }
}
