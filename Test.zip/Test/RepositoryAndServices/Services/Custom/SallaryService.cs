﻿using Domain.Models;
using Domain.ViewModel;
using RepositoryAndServices.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Services.Custom
{
    public class SallaryService : ISallaryService
    {
        private readonly IRepository<Salary> _repository;
        private readonly IRepository<Employee> _employee;
        private readonly IRepository<Department> _department;

        private readonly IEmployeeService _employeeService;
        private readonly IDepartmentService _departmentService;

        public SallaryService(IRepository<Salary> repository, IRepository<Employee> employee, IRepository<Department> department, IEmployeeService employeeService, IDepartmentService departmentService)
        {
            _repository = repository;
            _employee = employee;
            _department = department;
            _employeeService = employeeService;
            _departmentService = departmentService;
        }
        public async Task<bool> Delete(int id)
        {
            if (id != null)
            {
                Salary sal = await _repository.Get(id);
                if (sal != null)
                {
                    _ = _repository.Delete(sal);
                    return true;
                }
                else
                    return false;
            }
            else
            {
                return false;
            }
        }

        public Task<Salary> Find(Expression<Func<Salary, bool>> match)
        {
            return _repository.Find(match);
        }

        public async Task<ICollection<SalaryViewModel>> GetAll()
        {
            ICollection<SalaryViewModel> employeeViewModels = new List<SalaryViewModel>();

            ICollection<Salary> employees = await _repository.GetAll();
            foreach (Salary employee in employees)
            {
                SalaryViewModel emp = new()
                {
                    Id = employee.Id,
                    SalAmt = employee.SalAmt
                };

                employeeViewModels.Add(emp);
            }

            return employeeViewModels;
        }

        public async Task<SalaryViewModel> GetbyId(int id)
        {
            var emp = await _repository.Get(id);
            if (emp == null)
            {
                return null;
            }

            else
            {
                SalaryViewModel employee = new()
                {

                    Id = emp.Id,
                    SalAmt = emp.SalAmt

                };

                return employee;
            }
        }

        public async Task<bool> Insert(SalaryInsertModel salaryInsertModel)
        {
            var employee = await _employee.Find(x => x.Id == salaryInsertModel.Emp_Id);
            var department = await _department.Find(x => x.Id == salaryInsertModel.Dep_Id);

            var result = await _repository.Find(x => x.Emp_Id == employee.Id && x.Dep_Id == department.Id);

            if (salaryInsertModel.Emp_Id == employee.Id && salaryInsertModel.Dep_Id == department.Id)
            {
                Salary viewModel = new()
                {
                    SalAmt = salaryInsertModel.SalAmt,
                    Emp_Id = salaryInsertModel.Emp_Id,
                    Dep_Id = salaryInsertModel.Dep_Id
                };
                var enrollment = await _repository.Insert(viewModel);
                if (enrollment == true)
                {
                    return true;
                }
                else
                    return false;

            }
            else
                return false;
        }
        public async Task<bool> Update(SalaryUpdateModel salaryUpdateModel)
        {
            Salary userType = await _repository.Get(salaryUpdateModel.Id);

            userType.SalAmt = salaryUpdateModel.SalAmt;
            userType.UpdatedOn = DateTime.Now;
            userType.CreatedOn = DateTime.Now;
            var result = await _repository.Update(userType);

            if (result == true)
            {
                return true;
            }
            else
                return false;


        }

    }
}
