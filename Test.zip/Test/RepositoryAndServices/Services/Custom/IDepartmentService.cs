﻿using Domain.Models;
using Domain.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Services.Custom
{
    public interface IDepartmentService
    {
        Task<ICollection<DepartmentViewModel>> GetAll();
        Task<DepartmentViewModel> GetById(int id);

        Task<bool> Insert (DepartmentInsertModel DepInsertModel);
        Task<bool> Update (DepartmentUpdateModel departmentUpdate);
        Task<bool> Delete (int id);
        Task<Department> Find(Expression<Func<Department, bool>> match);
    }
}
