﻿using Domain.Models;
using Domain.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Services.Custom
{
    public interface ISallaryService
    {
        Task<ICollection<SalaryViewModel> > GetAll();

        Task<SalaryViewModel> GetbyId(int id);

        Task<bool> Insert(SalaryInsertModel salaryInsertModel);
        Task<bool> Update(SalaryUpdateModel salaryUpdateModel);

        Task <bool> Delete(int id);

        Task<Salary> Find(Expression<Func<Salary, bool>> match);
    }
}
