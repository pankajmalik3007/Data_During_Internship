﻿using Domain.Models;
using Domain.ViewModel;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using RepositoryAndServices.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Services.Custom
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IRepository<Employee> _repository;

        public EmployeeService(IRepository<Employee> repository)
        {
            _repository = repository;
        }

        public async Task<bool> Delete(int id)
        {
           if(id != null)
            {
                Employee emp = await _repository.Get(id);
                if(emp != null)
                {
                    _ = _repository.Delete(emp);
                    return true;
                }
                else
                {
                    return false;
                }
               

            }
           else { return false; }
        }

        public Task<Employee> Find(Expression<Func<Employee, bool>> match)
        {
            return _repository.Find(match);
        }

        public async Task<ICollection<EmployeeViewModel>> GetAll()
        {
           ICollection<EmployeeViewModel> employeeViewModels = new List<EmployeeViewModel>();

            ICollection<Employee> employees = await _repository.GetAll();
            foreach (Employee employee in employees)
            {
                EmployeeViewModel emp = new()
                {
                    Emp_Id=employee.Emp_Id,
                    Id = employee.Id,
                    Emp_Name = employee.Emp_Name,
                    Emp_Adress = employee.Emp_Adress,
                    Email = employee.Email
                };

                employeeViewModels.Add(emp);
            }
            
            return employeeViewModels;
        }

        public async Task<EmployeeViewModel> GetById(int id)
        {
            var emp = await _repository.Get(id);
            if (emp == null)
            {
                return null;
            }

            else
            {
                EmployeeViewModel employee = new()
                {
                    Emp_Id = emp.Emp_Id,
                    Id = emp.Id,
                    Emp_Name = emp.Emp_Name,
                    Emp_Adress = emp.Emp_Adress,
                    Email =emp.Email

                };

                return employee;
            }
        }

        public async Task<bool> Insert(EmployeeInsertModel employeeInsertModel)
        {
          
                Employee employee = new()
                {
                    Emp_Id = employeeInsertModel.Emp_Id,
                    Emp_Name= employeeInsertModel.Emp_Name,
                    Emp_Adress= employeeInsertModel.Emp_Adress,
                    Email=employeeInsertModel.Email,
                     CreatedOn = DateTime.Now,
                    UpdatedOn = DateTime.Now
                };
                var result = await _repository.Insert(employee);
                return result;
            }
        

        public async Task<bool> Update(EmployeeUpdateModel employeeUpdateModel)
        {
            Employee emp = await _repository.Get(employeeUpdateModel.Id);
            if (emp != null)
            {
                emp.Emp_Id = employeeUpdateModel.Emp_Id;
                emp.Emp_Name = employeeUpdateModel.Emp_Name;
                emp.Email = employeeUpdateModel.Email;
                emp.Emp_Adress = employeeUpdateModel.Emp_Adress;
                emp.UpdatedOn = DateTime.Now;
                emp.CreatedOn = DateTime.Now;
                var res = await _repository.Update(emp);
                return res;
            }
            else
            {
                return false;
            }

            }
           
        }
    }

