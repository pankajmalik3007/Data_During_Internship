﻿using Domain.Models;
using Domain.ViewModel;
using RepositoryAndServices.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Services.Custom
{
    public class DepartmentService : IDepartmentService
    {
        private readonly IRepository<Department> _repository;

        public DepartmentService(IRepository<Department> repository)
        {
            _repository = repository;
        }

        public async Task<bool> Delete(int id)
        {

            if (id != null)
            {
                Department emp = await _repository.Get(id);
                if (emp != null)
                {
                    _ = _repository.Delete(emp);
                    return true;
                }
                else
                {
                    return false;
                }


            }
            else { return false; }
        }
    

        public Task<Department> Find(Expression<Func<Department, bool>> match)
        {
            return _repository.Find(match);
        }

        public async  Task<ICollection<DepartmentViewModel>> GetAll()
        {
            ICollection<DepartmentViewModel> userTypeViewModels = new List<DepartmentViewModel>();
            ICollection<Department> userTypes = await _repository.GetAll();
            foreach (Department userType in userTypes)
            {
                DepartmentViewModel userTypeView = new()
                {
                    Dep_Id=userType.Dep_Id,
                    Id = userType.Id,
                    Dep_Name = userType.Dep_Name
                };
                userTypeViewModels.Add(userTypeView);
            }
            return userTypeViewModels;
        }

        public async Task<DepartmentViewModel> GetById(int id)
        {
            var emp = await _repository.Get(id);
            if (emp == null)
            {
                return null;
            }

            else
            {
                DepartmentViewModel employee = new()
                {Dep_Id = emp.Dep_Id,
                    Id = emp.Id,
                   Dep_Name = emp.Dep_Name

                };

                return employee;
            }
        }

        public async Task<bool> Insert(DepartmentInsertModel DepInsertModel)
        {

            Department employee = new()
            {
                Dep_Id = DepInsertModel.Dep_Id,
                Dep_Name = DepInsertModel.Dep_Name,
                CreatedOn = DateTime.Now,
                UpdatedOn = DateTime.Now
            };
            var result = await _repository.Insert(employee);
            return result;
        }

        public async Task<bool> Update(DepartmentUpdateModel departmentUpdate)
        {
            Department emp = await _repository.Get(departmentUpdate.Id);
            if (emp != null)
            {
                emp.Dep_Id = departmentUpdate.Dep_Id;
                emp.Dep_Name = departmentUpdate.Dep_Name;
                emp.UpdatedOn = DateTime.Now;
                emp.CreatedOn = DateTime.Now;
                var res = await _repository.Update(emp);
                return res;
            }
            else
            {
                return false;
            }

        }
    }
}
