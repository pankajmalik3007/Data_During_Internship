﻿using Domain;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryAndServices.Context;
using RepositoryAndServices.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryAndServices.Services.Generic
{
    public class Service<T> where T : BaseEntity
    {
        #region Property
        private readonly MainDbContext _applicationDbContext;
        private readonly IRepository<T> _repository;
        #endregion
        public Service(MainDbContext mainDbContext, IRepository<T> repository)
        {
            _applicationDbContext = mainDbContext;
            _repository = repository;
        }
        public Service(IRepository<T> repository)
        {
            _repository = repository;
        }

        public async Task<bool> Delete(T entity)
        {
            return await _repository.Delete(entity);
        }

        public Task<T> Get(int Id)
        {
            return _repository.Get(Id);
        }
        public T GetLast()
        {
            return _repository.GetLast();
        }


        public Task<ICollection<T>> GetAll()
        {
            return _repository.GetAll();
        }

      /*  public async Task<ICollection<Employee>> GetSalaryByEmployeeIdAsync(int id)
        {
            return await _applicationDbContext.Salaries
                .Where(s => s.Id == id)
                .ToListAsync();
        }*/

       /* public async Task<ICollection<Employee>> GetDepartmentByEmployeeNameAsync(string empName)
        {
            return await _applicationDbContext.Employees
                .Where(e => e.Emp_Name == empName)
                .ToListAsync();
        }*/

        public Task<bool> Insert(T entity)
        {
            return _repository.Insert(entity);
        }

        public Task<bool> Update(T entity)
        {
            return _repository.Update(entity);
        }
        public Task<T> Find(Expression<Func<T, bool>> match)
        {
            return _repository.Find(match);
        }
        public Task<ICollection<T>> FindAll(Expression<Func<T, bool>> match)
        {
            return _repository.FindAll(match);
        }
    }
}

