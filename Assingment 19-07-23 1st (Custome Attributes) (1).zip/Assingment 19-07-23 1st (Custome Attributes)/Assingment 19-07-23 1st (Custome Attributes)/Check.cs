﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Assingment_19_07_23_1st__Custome_Attributes_
{
    public class Stud_Info : CustomeAttributes
    {
        //Constructing Custom Attrbutes
        public Stud_Info(int id, string name, int age, string gen, string addr)
        {
            this.Stud_Id = id;
            this.Stud_Name = name;
            this.Stud_Age = age;
            this.Stud_Gender = gen;
            this.Stud_Addr = addr;
        }

        ///Getting The Values
        public int Id
        {
            get
            {
                return Stud_Id;
            }
        }

        public string Name
        {
            get
            {
                return Stud_Name;
            }
        }
        public int Age
        {
            get
            {
                return Stud_Age;
            }
        }
        public string Gen
        {
            get
            {
                return Stud_Gender;
            }
        }
        public string Addr
        {
            get
            {
                return Stud_Addr;
            }
        }
    }
    //Applying the custom attributes on target object
    [Stud_Info(1, "Pratik", 22, "Male", "Yeola")]
    [Stud_Info(2, "Pankaj", 23, "Male", "Vaijapur")]
    [Stud_Info(5, "Ram", 23, "Male", "Puna")]

    public class factorial
    {
        public int fact = 1;
        public int no = 5;

        //Applying the custom attributes on target method
        [Stud_Info(3, "Mayur", 23, "Male", "Yeola")]
        public void Logic()
        {
            for(int i = 1; i <= no;i++)
            {
                fact *= i;
            }
        }

        //Applying the custom attributes on target  method
        [Stud_Info(4, "Pavan", 22, "Male", "Kopargaon")]
        public void Display()
        {
            Logic();
            Console.WriteLine("Factorial is :- "+fact);
        }
    }

    public class Check
    {
        
        public static void Main(String[] args)
        {
            factorial f = new factorial();
            f.Display();

            Type type = typeof(factorial);

            //Iterating Through the Object Attributes & Accessing It Through The Reflection
            foreach(Object o in type.GetCustomAttributes(false))
            {
                Stud_Info std = (Stud_Info)o;

                if(null != std)
                {
                    Console.WriteLine("\nStudent Id is: {0}, For Object: {1}", std.Id,f.GetType());
                    Console.WriteLine("Student Name is: {0}", std.Name);
                    Console.WriteLine("Student Age is: {0}", std.Age);
                    Console.WriteLine("Student Gender is: {0}", std.Gen);
                    Console.WriteLine("Student Address is: {0}", std.Addr);
                }
            }

            //Iterating Through the Method Attributes & Accessing It Through The Reflection
            foreach (MethodInfo mi in type.GetMethods())
            {
                foreach(Attribute a in mi.GetCustomAttributes(true))
                {
                    Stud_Info std = (Stud_Info)a;

                    if (null != std)
                    {
                        Console.WriteLine("\nStudent Id is: {0}, For Method: {1}",std.Id,mi.Name);
                        Console.WriteLine("Student Name is: {0}",std.Name);
                        Console.WriteLine("Student Age is: {0}",std.Age);
                        Console.WriteLine("Student Gender is: {0}",std.Gen);
                        Console.WriteLine("Student Address is: {0}",std.Addr);
                    }
                }
            }
            Console.ReadLine();
        }
    }
    
}
