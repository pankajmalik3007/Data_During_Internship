﻿using Microsoft.EntityFrameworkCore;

namespace emp_sal_dep_table.Models
{
    public class YourDbContext : DbContext
    {
        public YourDbContext(DbContextOptions<YourDbContext> options) : base(options)
        {
        }

        // Define DbSet properties for your model classes
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Salary> Salaries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure your entity relationships, constraints, etc. here
            // For example, if you have relationships between models, define them here.
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Department)
                .WithMany(e=> e.Employees)
                .HasForeignKey(e => e.DepartmentId);

            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Salary)
                .WithMany(e=> e.Employees)
                .HasForeignKey(e => e.SalaryId);
        }
    }
}
