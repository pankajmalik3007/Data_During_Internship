﻿using System.ComponentModel.DataAnnotations;

namespace emp_sal_dep_table.Models
{
    public class Salary
    {
        public int SalaryId { get; set; }

        [Required]
        public double Amount { get; set; }
        public ICollection<Employee> Employees { get; set; }

    }
}
