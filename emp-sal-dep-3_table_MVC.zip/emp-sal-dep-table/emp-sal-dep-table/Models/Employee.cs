﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace emp_sal_dep_table.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required] 
        public string LastName { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }

        // Define foreign key for Department
        public int DepartmentId { get; set; }

        // Navigation property to access related Department
        [ForeignKey("DepartmentId")]
        public Department Department { get; set; }

        // Define foreign key for Salary
        public int SalaryId { get; set; }

        // Navigation property to access related Salary
        [ForeignKey("SalaryId")]
        public Salary Salary { get; set; }
    }

}

