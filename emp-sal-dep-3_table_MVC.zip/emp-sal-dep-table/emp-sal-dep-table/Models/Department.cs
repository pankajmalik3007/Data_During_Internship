﻿using System.ComponentModel.DataAnnotations;

namespace emp_sal_dep_table.Models
{
    public class Department
    {
        public int DepartmentId { get; set; }

        [Required]
        public string DepartmentName { get; set; }
        public ICollection<Employee> Employees { get; set; }

    }
}
