﻿using emp_sal_dep_table.Models;
using MessagePack;
using Microsoft.AspNetCore.Mvc;

namespace emp_sal_dep_table.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly YourDbContext _context; // Replace with your DbContext

        public DepartmentController(YourDbContext context)
        {
            _context = context;
        }

        // GET: Department
        public IActionResult Index()
        {
            var departments = _context.Departments.ToList();
            return View(departments);
        }

        // GET: Department/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Department/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create( int Id, Department department)
        {
            if (Id !=null)
            {
                _context.Departments.Add(department);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(department);
        }

        // GET: Department/Edit/5
        public IActionResult Edit(int id)
        {
            var department = _context.Departments.Find(id);
            if (department == null)
            {
                return NotFound();
            }
            return View(department);
        }

        // POST: Department/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Department department)
        {
            if (id != null)
            {
                _context.Update(department);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            
            return View(department);
        }

        // GET: Department/Delete/5
        public IActionResult Delete(int id)
        {
            var department = _context.Departments.Find(id);
            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // POST: Department/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var department = _context.Departments.Find(id);
            _context.Departments.Remove(department);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
