﻿using emp_sal_dep_table.Models;
using Microsoft.AspNetCore.Mvc;

namespace emp_sal_dep_table.Controllers
{
    public class SalaryController : Controller
    {
        private readonly YourDbContext _context; // Replace with your DbContext

        public SalaryController(YourDbContext context)
        {
            _context = context;
        }

        // GET: Salary
        public IActionResult Index()
        {
            var salaries = _context.Salaries.ToList();
            return View(salaries);
        }

        // GET: Salary/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Salary/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int ID, Salary salary)
        {
            if (ID !=null)
            {
                _context.Salaries.Add(salary);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(salary);
        }

        // GET: Salary/Edit/5
        public IActionResult Edit(int id)
        {
            var salary = _context.Salaries.Find(id);
            if (salary == null)
            {
                return NotFound();
            }
            return View(salary);
        }

        // POST: Salary/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Salary salary)
        {
          

            if (id !=null)
            {
                _context.Update(salary);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(salary);
        }

        // GET: Salary/Delete/5
        public IActionResult Delete(int id)
        {
            var salary = _context.Salaries.Find(id);
            if (salary == null)
            {
                return NotFound();
            }

            return View(salary);
        }

        // POST: Salary/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var salary = _context.Salaries.Find(id);
            _context.Salaries.Remove(salary);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
