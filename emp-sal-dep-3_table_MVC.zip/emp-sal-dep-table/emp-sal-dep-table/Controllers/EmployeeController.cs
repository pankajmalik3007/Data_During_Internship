﻿using emp_sal_dep_table.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace emp_sal_dep_table.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly YourDbContext _context; // Replace with your DbContext

        public EmployeeController(YourDbContext context)
        {
            _context = context;
        }

        // GET: Employee
        public IActionResult Index()
        {
            var employees = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Salary)
                .ToList();
            return View(employees);
        }

        // GET: Employee/Create
        public IActionResult Create()
        {
            ViewData["DepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName");
            ViewData["SalaryId"] = new SelectList(_context.Salaries, "SalaryId", "Amount");
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int id, [Bind("EmployeeId , FirstName, LastName, DateOfBirth, DepartmentId, DepartmentName,SalaryId,Amount ")]Employee employee)
        {
            if (id != null)
            {
                _context.Employees.Add(employee);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewData["DepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName" ,employee.DepartmentId);
            ViewData["SalaryId"] = new SelectList(_context.Salaries, "SalaryId", "Amount", employee.SalaryId);
            ViewBag.Salaries = _context.Salaries.ToList();
            return View(employee);
        }

        // GET: Employee/Edit/5
        public IActionResult Edit(int id)
        {
            var employee = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Salary)
                .FirstOrDefault(e => e.EmployeeId == id);

            if (employee == null)
            {
                return NotFound();
            }


            ViewData["DepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName", employee.DepartmentId);
            ViewData["SalaryId"] = new SelectList(_context.Salaries, "SalaryId", "Amount", employee.SalaryId);
            return View(employee);
        }

        // POST: Employee/Edit/5
       [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("EmployeeId , FirstName, LastName, DateOfBirth, DepartmentId, DepartmentName,SalaryId,Amount ")] Employee employee)
        {
            if (id > 0) // Check if the ID is valid (greater than zero)
            {
                // Update the employee record
                _context.Employees.Update(employee);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            // If the ID is not valid, return to the edit view with the same employee data
            ViewData["DepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName", employee.DepartmentId);
            ViewData["SalaryId"] = new SelectList(_context.Salaries, "SalaryId", "Amount", employee.SalaryId);
            return View(employee);
        }

        // GET: Employee/Delete/5
        public IActionResult Delete(int id)
        {
            var employee = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Salary)
                .FirstOrDefault(e => e.EmployeeId == id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employee/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var employee = _context.Employees.Find(id);
            _context.Employees.Remove(employee);
            _context.SaveChanges();
            return RedirectToAction("Index");

        }
    }
}
