﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assingment_19_07_23_1st__Custome_Attributes_
{
    [AttributeUsage(AttributeTargets.Class|
        AttributeTargets.Constructor|
        AttributeTargets.Field|
        AttributeTargets.Method|
        AttributeTargets.Parameter|
        AttributeTargets.Property,
        AllowMultiple =true)]
    public class CustomeAttributes : System.Attribute
    {
        public int Stud_Id { get; set; }
        public string Stud_Name { get;set; }
        public int Stud_Age { get; set; }
        public string Stud_Gender { get; set; }
        public string Stud_Addr { get; set; }   

    }
}
