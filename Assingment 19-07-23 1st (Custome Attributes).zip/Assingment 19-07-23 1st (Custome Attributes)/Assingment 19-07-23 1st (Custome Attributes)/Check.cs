﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static Assingment_19_07_23_1st__Custome_Attributes_.CustomeAttributes;

namespace Assingment_19_07_23_1st__Custome_Attributes_
{
    public class Stud_Info : CustomeAttributes
    {
        public Stud_Info(int id, string name, int age, string gen, string addr)
        {
            this.Stud_Id = id;
            this.Stud_Name = name;
            this.Stud_Age = age;
            this.Stud_Gender = gen;
            this.Stud_Addr = addr;
        }

        public int Id
        {
            get
            {
                return Stud_Id;
            }
        }

        public string Name
        {
            get
            {
                return Stud_Name;
            }
        }
        public int Age
        {
            get
            {
                return Stud_Age;
            }
        }
        public string Gen
        {
            get
            {
                return Stud_Gender;
            }
        }
        public string Addr
        {
            get
            {
                return Stud_Addr;
            }
        }
    }
    [Stud_Info(1, "Pratik", 22, "Male", "Yeola")]
    [Stud_Info(2, "Pankaj", 23, "Male", "vaijapur")]

    public class factorial
    {
        public int fact = 1;
        public int no = 5;

        [Stud_Info(3, "Mayur", 23, "Male", "Yeola")]
        public void Logic()
        {
            for(int i = 1; i <= no;i++)
            {
                fact *= i;
            }
        }
        [Stud_Info(4, "Pavan", 22, "Male", "Kopargaon")]
        public void Display()
        {
            Logic();
            Console.WriteLine("Factorial is :- "+fact);
        }
    }

    public class Check
    {
        
        public static void Main(String[] args)
        {
            factorial f = new factorial();
            f.Display();

            Type type = typeof(factorial);

            foreach(Object o in type.GetCustomAttributes(false))
            {
                Stud_Info std = (Stud_Info)o;

                if(null != std)
                {
                    Console.WriteLine($"Student Id is {std.Id}");
                    Console.WriteLine($"Student Name is {std.Name}");
                    Console.WriteLine($"Student Age is {std.Age}");
                    Console.WriteLine($"Student Gender is {std.Gen}");
                    Console.WriteLine($"Student Address is {std.Addr}");
                }
            }

            foreach(MethodInfo mi in type.GetMethods())
            {
                foreach(Attribute a in mi.GetCustomAttributes(true))
                {
                    Stud_Info std = (Stud_Info)a;

                    if (null != std)
                    {
                        Console.WriteLine($"Student Id is {std.Id}");
                        Console.WriteLine($"Student Name is {std.Name}");
                        Console.WriteLine($"Student Age is {std.Age}");
                        Console.WriteLine($"Student Gender is {std.Gen}");
                        Console.WriteLine($"Student Address is {std.Addr}");
                    }
                }
            }
        }
    }
    
}
