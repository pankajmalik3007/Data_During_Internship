﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra_Library.Services.Custom_Services.WithdrawlServices
{
    public interface IWithdrawlService
    {
        Task<bool> Delete(int Id);
    }
}
