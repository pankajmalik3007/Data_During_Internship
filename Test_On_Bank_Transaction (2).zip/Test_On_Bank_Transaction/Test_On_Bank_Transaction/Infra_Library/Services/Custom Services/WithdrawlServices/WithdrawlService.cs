﻿using Domain_Library.Model;
using Infra_Library.Repositories;
using Infra_Library.Services.Custom_Services.TransactionTypeServise;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra_Library.Services.Custom_Services.WithdrawlServices
{
    public class WithdrawlService : IWithdrawlService
    {
        private readonly IRepository<Transaction> _user;
        private readonly ITransactionTypeServise _userType;

        public WithdrawlService(IRepository<Transaction> user, ITransactionTypeServise userType)
        {
            _user = user;
            _userType = userType;
        }

        public async Task<bool> Delete(int Id)
        {
            if (Id != null)
            {
                Transaction userAsSupplier = await _user.Get(Id);
                if (userAsSupplier != null)
                {
                    _ = _user.Delete(userAsSupplier);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
    }
}
