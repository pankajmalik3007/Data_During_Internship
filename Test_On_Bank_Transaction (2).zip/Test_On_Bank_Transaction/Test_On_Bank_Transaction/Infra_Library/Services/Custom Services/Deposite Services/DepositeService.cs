﻿using Domain_Library.Model;
using Domain_Library.View_Model;
using Infra_Library.Repositories;
using Infra_Library.Services.Custom_Services.TransactionTypeServise;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra_Library.Services.Custom_Services.Deposite_Services
{
    public class DepositeService : IDepositeService
    {
        private readonly IRepository<Transaction> _user;
        private readonly ITransactionTypeServise _userType;

        public DepositeService(IRepository<Transaction> user, ITransactionTypeServise userType)
        {
            _user = user;
            _userType = userType;
        }

        public async Task<bool> Insert(TransactionInsertModel userInsertModel)
        {
           
                var usertype = await _userType.Find(x => x.TransactionTypeName == "Deposite");
                if (usertype != null)
                {

                    Transaction supplier = new()
                    {
                        
                        TransactionId = userInsertModel.TransactionId,
                        TransactionDate = DateTime.Now,
                        Amount = userInsertModel.Amount,
                        AccountId = userInsertModel.AccountId,
                        TransactionTypeId = usertype.Id,
                        Created = DateTime.Now,
                        LastUpdated = DateTime.Now


                    };
                    var result = await _user.Insert(supplier);
                    return result;
                }
                else
                    return false;
            }

        }
    }

