﻿using Domain_Library.View_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra_Library.Services.Custom_Services.Deposite_Services
{
    public interface IDepositeService
    {
        Task<bool> Insert(TransactionInsertModel userInsertModel);
    }
}
