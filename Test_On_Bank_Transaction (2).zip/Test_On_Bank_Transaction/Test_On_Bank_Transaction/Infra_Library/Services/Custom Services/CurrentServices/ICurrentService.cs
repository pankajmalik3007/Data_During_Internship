﻿using Domain_Library.Model;
using Domain_Library.View_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Infra_Library.Services.Custom_Services.CurrentServices
{
    public interface ICurrentService
    {
        Task<ICollection<AccountViewModel>> GetAll();
        Task<AccountViewModel> Get(int Id);
        Task<bool> Insert(AccountInsertModel userInsertModel);
        Task<bool> Update(AccountUpdateModel userUpdateModel);
        Task<bool> Delete(int Id);
        Task<Account> Find(Expression<Func<Account, bool>> match);
    }
}
