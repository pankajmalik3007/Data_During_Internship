﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Library.View_Model
{
    public class TransactionViewModel
    {
        public int Id { get; set; }
        public int TransactionId { get; set; }
        public int Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public List<TransactionTypeViewModel> TransactionType { get; set; } = new List<TransactionTypeViewModel>();
        public List<AccountViewModel> Transactions { get; set; } = new List<AccountViewModel>();
        public List<UserViewModel> userViewModels { get; set; } = new List<UserViewModel>();

    }
    public class TransactionInsertModel
    {
        public int TransactionId { get; set; }
        public int Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public int AccountId { get; set; }
        public int TransactionTypeId { get; set; }

    }

    public class TransactionUpdateModel : TransactionInsertModel
    {
        public int Id { get; set; }
    }



}
