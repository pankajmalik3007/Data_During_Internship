﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Library.View_Model
{
    public class AccountViewModel
    {
        public int Id { get; set; }
        public int AccountId { get; set; }
        public string AccountNumber { get; set; }
        public int Balance { get; set; }

        public List<AccountTypeViewModel> AccountType { get; set; } = new List<AccountTypeViewModel>();
    }

    public class AccountInsertModel 
    {
        public int AccountId { get; set; }
        public string AccountNumber { get; set; }
        public int Balance { get; set; }

        public int UserId { get; set; }
        public int AccountTypeId { get; set; }
    }

    public class AccountUpdateModel: AccountInsertModel
    {
        public int Id { get; set; }
    }

}
