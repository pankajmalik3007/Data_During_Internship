﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Library.View_Model
{
    public class AccountTypeViewModel
    {
        public int Id { get; set; }
        public string AccountTypeName { get; set; }
    }

    public class AccountTypeInsertModel
    {
        public string AccountTypeName { get; set; }
    }

    public class AccountTypeUpdateModel : AccountTypeInsertModel
    {
        public int Id { get; set; }
    }
}
