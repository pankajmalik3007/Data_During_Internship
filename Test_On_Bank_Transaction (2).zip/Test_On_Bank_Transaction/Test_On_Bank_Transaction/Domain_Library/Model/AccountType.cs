﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain_Library.Model
{
    public class AccountType : BaseEntity
    {
        public string AccountTypeName { get; set; }
       
        
        [JsonIgnore]
        public List<Account> Accounts { get; set; } 
    }

}
