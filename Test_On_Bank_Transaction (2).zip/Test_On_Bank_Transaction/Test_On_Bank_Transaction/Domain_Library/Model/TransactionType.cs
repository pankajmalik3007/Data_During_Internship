﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain_Library.Model
{
    public class TransactionType : BaseEntity
    {
        public string TransactionTypeName { get; set; }
        [JsonIgnore]
        public virtual List<Transaction> Transactions { get; set; } 
    }

}
