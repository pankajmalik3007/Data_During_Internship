﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain_Library.Model
{
    public class Transaction : BaseEntity
    {
        public int TransactionId { get; set; }
        public int Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public int AccountId { get; set; }
        public int TransactionTypeId { get; set; }

        [JsonIgnore]
        public Account Account { get; set; } 
        public TransactionType TransactionType { get; set; } 
    }

}
