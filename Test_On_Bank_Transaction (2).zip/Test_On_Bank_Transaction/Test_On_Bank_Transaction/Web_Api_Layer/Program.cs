using Infra_Library._dbContext_main;
using Infra_Library.Repositories;
using Infra_Library.Services.Custom_Services.AccountTypeServices;
using Infra_Library.Services.Custom_Services.CurrentServices;
using Infra_Library.Services.Custom_Services.CustomerServices;
using Infra_Library.Services.Custom_Services.Deposite_Services;
using Infra_Library.Services.Custom_Services.ManagerServices;
using Infra_Library.Services.Custom_Services.SavingServices;
using Infra_Library.Services.Custom_Services.TransactionTypeServise;
using Infra_Library.Services.Custom_Services.UserTypeServices;
using Infra_Library.Services.Custom_Services.WithdrawlServices;
using Infra_Library.Services.General_Services;
using Microsoft.EntityFrameworkCore;
using Web_Api_Layer.Middleware.Auth;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddDbContext<MainDbContext>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("Database")));

#region Cors Configuration
builder.Services.AddCors(c =>
{
    c.AddPolicy("AllowOrigin", options => options.WithOrigins("http://localhost:3000").AllowAnyHeader().AllowAnyMethod());
});
#endregion
builder.Services.AddSwaggerGen();
#region Dependency Injections
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddTransient(typeof(IService<>), typeof(Service<>));
builder.Services.AddTransient(typeof(IUserTypeService), typeof(UserTypeService));
builder.Services.AddTransient(typeof(ICustomerService), typeof(CustomerService));
builder.Services.AddTransient(typeof(IJWTAuthManager), typeof(JWTAuthManager));
builder.Services.AddTransient(typeof(ICurrentService), typeof(CurrentService));
builder.Services.AddTransient(typeof(ISavingService), typeof(SavingService));
builder.Services.AddTransient(typeof(IAccountTypeService), typeof(AccountService));
builder.Services.AddTransient(typeof(ITransactionTypeServise), typeof(TransactionTypeServise));
builder.Services.AddTransient(typeof(IManagerService), typeof(ManagerService));
builder.Services.AddTransient(typeof(IWithdrawlService), typeof(WithdrawlService));
builder.Services.AddTransient(typeof(IDepositeService), typeof(DepositeService));




#endregion

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
