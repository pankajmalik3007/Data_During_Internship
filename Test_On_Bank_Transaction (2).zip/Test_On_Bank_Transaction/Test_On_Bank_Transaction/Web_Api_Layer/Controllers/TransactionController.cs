﻿using Domain_Library.Model;
using Domain_Library.View_Model;
using Infra_Library._dbContext_main;
using Infra_Library.Services.Custom_Services.CustomerServices;
using Infra_Library.Services.Custom_Services.Deposite_Services;
using Infra_Library.Services.Custom_Services.ManagerServices;
using Infra_Library.Services.Custom_Services.TransactionTypeServise;
using Infra_Library.Services.Custom_Services.UserTypeServices;
using Infra_Library.Services.Custom_Services.WithdrawlServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Identity.Client;
using System.Buffers.Text;
using System.Collections.Generic;
using System.IO;

namespace Web_Api_Layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {



        private readonly MainDbContext _context; // Replace YourDbContext with your actual DbContext class name

        public TransactionController(MainDbContext context)
        {
            _context = context;
        }

        // Endpoint for deposit operation
        [HttpPost("deposit")]
        [HttpPost]
        public async Task<IActionResult> Deposit([FromForm] TransactionInsertModel transaction)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (transaction.Amount <= 0)
            {
                ModelState.AddModelError("Amount", "Invalid deposit amount.");
                return BadRequest(ModelState);
            }

            var account = await _context.Accounts.FindAsync(transaction.AccountId);

            if (account == null)
            {
                return NotFound("Account not found.");
            }

            // Create a new deposit transaction
            var depositTransaction = new Transaction
            {
                Amount = transaction.Amount,
                TransactionDate = DateTime.Now,
                AccountId = account.AccountId,
                TransactionTypeId = transaction.TransactionTypeId
            };

            // Update account balance
            account.Balance += depositTransaction.Amount;

            try
            {
                _context.Transactions.Add(depositTransaction);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

            return Ok("Deposit successful.");
        }



        // Endpoint for withdrawal operation
        [HttpPost("withdraw")]
        public async Task<IActionResult> Withdraw([FromBody] Transaction transaction)
        {
            try
            {
                if (transaction.Amount <= 0)
                {
                    return BadRequest("Invalid withdrawal amount.");
                }

                var account = await _context.Accounts
                    .Include(a => a.Transactions)
                    .FirstOrDefaultAsync(a => a.AccountId == transaction.AccountId);

                if (account == null)
                {
                    return NotFound("Account not found.");
                }

                // Check if there is sufficient balance
                var balance = account.Transactions.Sum(t => t.Amount);
                if (balance < transaction.Amount)
                {
                    return BadRequest("Insufficient balance.");
                }

                // Create a new withdrawal transaction
                var withdrawalTransaction = new Transaction
                {
                    Amount = -transaction.Amount, // Negative amount for withdrawal
                    TransactionDate = DateTime.Now,
                    AccountId = account.AccountId,
                    TransactionTypeId = transaction.TransactionTypeId
                };

                // Update account balance
                account.Transactions.Add(withdrawalTransaction);
                account.AccountType = account.AccountType;
                account.User = account.User;
                _context.Transactions.Add(withdrawalTransaction);
                await _context.SaveChangesAsync();

                return Ok("Withdrawal successful.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }

}