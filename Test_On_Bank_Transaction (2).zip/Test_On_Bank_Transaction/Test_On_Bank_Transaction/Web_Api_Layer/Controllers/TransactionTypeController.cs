﻿using Domain_Library.View_Model;
using Infra_Library.Services.Custom_Services.TransactionTypeServise;
using Infra_Library.Services.Custom_Services.UserTypeServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web_Api_Layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionTypeController : ControllerBase
    {

        #region Private Variables and Constructor
        private readonly ITransactionTypeServise _serviceUserType;
        public TransactionTypeController(ITransactionTypeServise serviceUserType)
        {
            _serviceUserType = serviceUserType;
        }
        #endregion

        [Route("GetAllUserType")]
        [HttpGet]
        public async Task<ActionResult<TransactionTypeViewModel>> GetAllUserType()
        {
            var result = await _serviceUserType.GetAll();

            if (result == null)
                return BadRequest("No Records Found, Please Try Again After Adding them...!");

            return Ok(result);
        }
        [Route("GetUserType")]
        [HttpGet]
        public async Task<ActionResult<TransactionTypeViewModel>> GetUserType(int Id)
        {
            if (Id != null)
            {
                var result = await _serviceUserType.Get(Id);

                if (result == null)
                    return BadRequest("No Records Found, Please Try Again After Adding them...!");

                return Ok(result);
            }
            else
                return NotFound("Invalid UserType ID, Please Entering a Valid One...!");
        }

        [Route("InsertUserType")]
        [HttpPost]
        public async Task<IActionResult> InsertUserType(TransactionTypeInsertModel TransactionTypeInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Insert(TransactionTypeInsertModel);
                if (result == true)
                    return Ok("UserType Inserted Successfully...!");
                else
                    return BadRequest("Something Went Wrong, UserType Is Not Inserted, Please Try After Sometime...!");
            }
            else
                return BadRequest("Invalid UserType Information, Please Provide Correct Details for UserType...!");
        }

        [Route("UpdateUserType")]
        [HttpPut]
        public async Task<IActionResult> UpdateUserType(TransactionTypeUpdateModel TransactionTypeUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Update(TransactionTypeUpdateModel);
                if (result == true)
                    return Ok(TransactionTypeUpdateModel);
                else
                    return BadRequest("Something went wrong, Please Try again later...!");
            }
            else
                return BadRequest("Invalid UserType Information, Please Provide Correct Details for UserType...!");
        }
        [Route("DeleteUserType")]
        [HttpDelete]

        public async Task<IActionResult> DeleteUserType(int Id)
        {
            var result = await _serviceUserType.Delete(Id);
            if (result == true)
                return Ok("UserType Deleted Successfully...!");
            else
                return BadRequest("UserType is not deleted, Please Try again later...!");

        }
    }
}
