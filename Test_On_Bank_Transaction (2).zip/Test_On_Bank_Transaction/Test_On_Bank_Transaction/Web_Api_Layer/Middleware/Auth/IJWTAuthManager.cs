﻿using Domain_Library.Model;

namespace Web_Api_Layer.Middleware.Auth
{
    public interface IJWTAuthManager
    {
        string GenerateJWT(User user);
    }
}
