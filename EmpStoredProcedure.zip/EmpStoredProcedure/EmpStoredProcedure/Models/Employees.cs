﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace EmpStoredProcedure.Models
{
    public class Employees
    {
        [Key]
        [Display(Name = "Employee Id")]
        public int Emp_Id { get; set; }

        [Required(ErrorMessage = "Please Enter Your Name....!")]
        [Display(Name = "Employee Name")]
        [Column(TypeName = "Varchar(20)")]
        public string Emp_Name { get; set; }

        [Required(ErrorMessage = "Please Enter Your Address.....!")]
        [Display(Name = "Employee Address")]
        [Column(TypeName = "Varchar(50)")]
        public string Emp_Addr { get; set; }

        [Required(ErrorMessage = "Please Enter Your Mobile Number........!")]
        [Display(Name = "Mobile Number")]
        [Column(TypeName = "Varchar(10)")]
        [MaxLength(10, ErrorMessage = "Mobile number must be have 10 digits........!")]
        public string Emp_PhNo { get; set; }

        [Required(ErrorMessage = "Please Enter Your Sallary.....!")]
        [Display(Name = "Sallary")]
        [Column(TypeName = "decimal")]
        public decimal Emp_Sal { get; set; }

        [Required(ErrorMessage = "Please Enter Your DOB")]
        [Display(Name = "DOB")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime Emp_DOB { get; set; }

        [Required(ErrorMessage = "Please Enter Your Age")]
        [Display(Name = "Age")]
        public int Emp_Age { get; set; }

        public string Result;
    }
}
