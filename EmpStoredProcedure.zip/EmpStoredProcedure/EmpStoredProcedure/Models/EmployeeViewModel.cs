﻿namespace EmpStoredProcedure.Models
{
    public class EmployeeViewModel
    {
        public int Emp_Id { get; set; }
        public string Emp_Name { get; set; }

        public string Emp_Addr { get; set; }
        public string Emp_PhNo { get; set; }


        public decimal Emp_Sal { get; set; }

        public DateTime Emp_DOB { get; set; }

  
        public int Emp_Age { get; set; }

        public string Result;
    }
}
