﻿using EmpStoredProcedure.Context;
using EmpStoredProcedure.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace EmpStoredProcedure.Controllers
{
    public class EmployeesController : Controller
    {
        private MainDbContext Context { get; }
        private IConfiguration _configuration;
        public EmployeesController(MainDbContext _context, IConfiguration configuration)
        {
            this.Context = _context;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            List<Employees> employees = this.Context.SearchEmployee("").ToList();
            return View(employees);
        }

        [HttpPost]
        public IActionResult Index(string empname)
        {
            List<Employees> employees = this.Context.SearchEmployee(empname).ToList();
            return View(employees);
        }

        public IActionResult Details(int id)
        {
            if (id == null)
            {
                return NotFound();

            }
            var employee = this.Context.Employee();

            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Employees  employee)
        {
            if (ModelState.IsValid)
            {
                var result = await Context.InsertOrUpdateEmployee(employee.Emp_Id, employee.Emp_Name, employee.Emp_Addr, employee.Emp_PhNo, employee.Emp_Sal, employee.Emp_DOB, employee.Emp_Age);

                if (result.StartsWith("Error"))
                {
                    ModelState.AddModelError(string.Empty, result);
                    return View(employee);
                }

                return RedirectToAction("Index");
            }
            return View(employee);
        }


        public IActionResult Update(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = Context.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id, [Bind("Emp_Id,Emp_Name,Emp_Addr,Emp_PhNo,Emp_Sal,Emp_DOB,Emp_Age")] Employees employee)
        {
            if (id != employee.Emp_Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var result = await Context.UpdateEmployee(employee.Emp_Id, employee.Emp_Name, employee.Emp_Addr, employee.Emp_PhNo, employee.Emp_Sal, employee.Emp_DOB, employee.Emp_Age);

                if (result.StartsWith("Error"))
                {
                    ModelState.AddModelError(string.Empty, result);
                    return View(employee);
                }

                return RedirectToAction("Index");
            }
            return View(employee);
        }


        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = Context.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var result = await Context.DeleteEmployee(id);

            if (result.StartsWith("Error"))
            {
                ModelState.AddModelError(string.Empty, result);
                return View();
            }

            return RedirectToAction("Index");
        }
    }
}
