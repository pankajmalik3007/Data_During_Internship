﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmpStoredProcedure.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Emp_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Emp_Name = table.Column<string>(type: "Varchar(20)", nullable: false),
                    Emp_Addr = table.Column<string>(type: "Varchar(50)", nullable: false),
                    Emp_PhNo = table.Column<string>(type: "Varchar(10)", maxLength: 10, nullable: false),
                    Emp_Sal = table.Column<string>(type: "Varchar(10)", nullable: false),
                    Emp_DOB = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Emp_Age = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Emp_Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
