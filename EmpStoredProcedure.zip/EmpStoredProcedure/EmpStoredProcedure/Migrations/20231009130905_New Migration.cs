﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmpStoredProcedure.Migrations
{
    /// <inheritdoc />
    public partial class NewMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "Emp_Sal",
                table: "Employees",
                type: "decimal(18,0)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "Varchar(10)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Emp_Sal",
                table: "Employees",
                type: "Varchar(10)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,0)");
        }
    }
}
