﻿using EmpStoredProcedure.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace EmpStoredProcedure.Context
{
    public class MainDbContext : DbContext
    {
        public MainDbContext(DbContextOptions<MainDbContext> option) : base(option)
        {

        }

        public DbSet<Employees> Employees { get; set; }

        public IQueryable<Employees> SearchEmployee(string EmployeeName)
        {
            SqlParameter eEmployeeName = new SqlParameter("@EmployeeName", EmployeeName);

            return this.Employees.FromSqlRaw("Execute Employees_SearchEmployee @EmployeeName", eEmployeeName);
        }

        public IQueryable<Employees> Employee()
        {
           /* SqlParameter eEmployeeName = new SqlParameter();*/

            return this.Employees.FromSqlRaw("Execute Employee_DetailsEmployee");
        }

        public async Task<string> InsertOrUpdateEmployee(int empId, string empName, string empAddr, string empPhNo, decimal empSalary, DateTime empDOB, int empAge)
        {
            var empIdParam = new SqlParameter("@EmpId", empId);
            var empNameParam = new SqlParameter("@EmpName", empName);
            var empAddrParam = new SqlParameter("@EmpAddr", empAddr);
            var empPhNoParam = new SqlParameter("@EmpPhNo", empPhNo);
            var empSalaryParam = new SqlParameter("@EmpSalary", empSalary);
            var empDOBParam = new SqlParameter("@EmpDOB", empDOB);
            var empAgeParam = new SqlParameter("@EmpAge", empAge);

            var result = await Database.ExecuteSqlRawAsync("EXEC Employee_InsertionOnEmployee @EmpId, @EmpName, @EmpAddr, @EmpPhNo, @EmpSalary, @EmpDOB, @EmpAge",
                empIdParam, empNameParam, empAddrParam, empPhNoParam, empSalaryParam, empDOBParam, empAgeParam);

            return result == 1 ? "Success" : "Error: Employee with the provided EmpId already exists.";
        }


        public async Task<string> UpdateEmployee(int empId, string empName, string empAddr, string empPhNo, decimal empSalary, DateTime empDOB, int empAge)
        {
            var empIdParam = new SqlParameter("@EmpId", empId);
            var empNameParam = new SqlParameter("@EmpName", empName);
            var empAddrParam = new SqlParameter("@EmpAddr", empAddr);
            var empPhNoParam = new SqlParameter("@EmpPhNo", empPhNo);
            var empSalaryParam = new SqlParameter("@EmpSalary", empSalary);
            var empDOBParam = new SqlParameter("@EmpDOB", empDOB);
            var empAgeParam = new SqlParameter("@EmpAge", empAge);

            var result = await Database.ExecuteSqlRawAsync("EXEC Employee_UpdateEmployee @EmpId, @EmpName, @EmpAddr, @EmpPhNo, @EmpSalary, @EmpDOB, @EmpAge",
                empIdParam, empNameParam, empAddrParam, empPhNoParam, empSalaryParam, empDOBParam, empAgeParam);

            return result == 1 ? "Success" : "Error: Employee with the provided EmpId does not exist.";
        }


        public async Task<string> DeleteEmployee(int empId)
        {
            var empIdParam = new SqlParameter("@EmpId", empId);

            var result = await Database.ExecuteSqlRawAsync("EXEC Employee_DeleteEmployee @EmpId", empIdParam);

            return result == 1 ? "Success" : "Error: Employee ID with the provided EmpId does not exist.";
        }


    }
}
