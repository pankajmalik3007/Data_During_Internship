﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using One_To_Many_ModelPopup.Models;

namespace One_To_Many_ModelPopup.Controllers
{
    public class EnrollmentController : Controller
    {
        private readonly MainDBContext _context;
        public EnrollmentController(MainDBContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            var enrol = await _context.Enrollments.Include(d => d.Student).Include(d => d.Course).ToListAsync();
            return View(enrol);
        }
        [HttpGet]
        public async Task<IActionResult>AddOrEdit(int id = 0)
        {
            if (id == 0)
            {
                ViewData["StudId"] = new SelectList(_context.Students, "StudId","FirstName","LastName","DOB");
                ViewData["CourseId"] = new SelectList(_context.Courses, "CourseId", "CourseName", "Instructor", "Credit");
                return View(new Course());
            }
            else
            {
                var emp = await _context.Courses.FindAsync(id);
                if (emp == null)
                {
                    return NotFound();
                }
                //  ViewData["EnrollmentId"] = new SelectList(_context.Enrollments, "EnrollmentId", "StudId", "CourseId", "DateOfEnrollment");
                return View(emp);
            }
        }
        [HttpPost]
        public async Task<IActionResult>AddOrEdit(int id,[Bind("EnrollmentId,CourseId,StudId,DateOfEnrollment")]Enrollment enrollment)
        {
            if (id == 0)
            {
                ViewData["StudId"] = new SelectList(_context.Students, "StudId", "FirstName", "LastName", "DOB");
                ViewData["CourseId"] = new SelectList(_context.Courses, "CourseId", "CourseName", "Instructor", "Credit");
                _context.Add(enrollment);
                await _context.SaveChangesAsync();
            }
            else
            {
                try
                {
                    ViewData["StudId"] = new SelectList(_context.Students, "StudId", "FirstName", "LastName", "DOB");
                    ViewData["CourseId"] = new SelectList(_context.Courses, "CourseId", "CourseName", "Instructor", "Credit");
                    _context.Update(enrollment);
                    await _context.SaveChangesAsync();
                }
                catch(DbUpdateConcurrencyException)
                {
                    if (!EnrollmentExist(enrollment.EnrollmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return Json(new { isValid = true, html = Helper.viewtostring(this, "_ViewAll", _context.Enrollments.ToListAsync()) });

            }
            return Json(new { isValid = false, html = Helper.viewtostring(this, "AddOrEdit", enrollment) });

        }

        private bool EnrollmentExist(int enrollmentId)
        {
            throw new NotImplementedException();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var enrol = await _context.Enrollments.Include(d => d.Student).Include(d => d.Course).FirstOrDefaultAsync(d => d.EnrollmentId == id);
            _context.Enrollments.Remove(enrol);
            await _context.SaveChangesAsync();
            return Json(new { html = Helper.viewtostring(this, "_ViewAll", enrol) });
        }
        /* public IActionResult GetCourseByFName(string name)
         {
             if (string.IsNullOrEmpty(name))
             {
                 // Display a message asking for the student name.
                 ViewData["Message"] = "Please provide a student name.";
             }
             else
             {
                 // Find students with matching first name
                 var studentIds = _context.Students
                     .Where(s => s.FirstName.ToLower().Contains(name.ToLower()))
                     .Select(s => s.StudId)
                     .ToList();

                 if (studentIds.Count == 0)
                 {
                     ViewData["Message"] = "No students found with the specified name.";
                 }
                 else
                 {
                     // Find enrollments for students with matching IDs
                     var enrollments = _context.Enrollments
                         .Include(e => e.Course)
                         .Where(e => studentIds.Contains(e.StudId))
                         .ToList();

                     ViewData["SearchName"] = name;
                     ViewData["Enrollments"] = enrollments;
                 }
             }

             return View();
         }
 */
        public IActionResult GetCourseByStudentId(int studentId)
        {
            if (studentId <= 0)
            {
                // Display a message asking for a valid student ID.
                ViewData["Message"] = "Please provide a valid student ID.";
            }
            else
            {
                // Find enrollments for the specified student ID
                var enrollments = _context.Enrollments
                    .Include(e => e.Course)
                    .Where(e => e.StudId == studentId)
                    .ToList();

                if (enrollments.Count == 0)
                {
                    ViewData["Message"] = "No enrollments found for the specified student ID.";
                }
                else
                {
                    ViewData["StudentId"] = studentId;
                    ViewData["Enrollments"] = enrollments;
                }
            }

            return View();
        }















    }
}
