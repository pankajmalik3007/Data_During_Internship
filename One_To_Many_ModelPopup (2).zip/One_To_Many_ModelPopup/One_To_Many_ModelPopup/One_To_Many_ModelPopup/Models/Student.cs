﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace One_To_Many_ModelPopup.Models
{
    public class Student
    {
        [Key]
        public int StudId { get; set; } 
       
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Adress { get; set; }
        [JsonIgnore]
        public virtual ICollection<Enrollment> Enrollments { get; set; }
    }
}
