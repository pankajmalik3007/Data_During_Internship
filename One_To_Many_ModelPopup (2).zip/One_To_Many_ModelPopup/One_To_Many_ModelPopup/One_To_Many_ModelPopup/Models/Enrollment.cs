﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace One_To_Many_ModelPopup.Models
{
    public class Enrollment
    {
        [Key]
        
        public int EnrollmentId {  get; set; }
        public int StudId { get; set; }
        public int CourseId { get; set; }

        public DateTime DateOfEnrollment { get; set; }

        [JsonIgnore]
        public Student Student { get; set; }
        public Course Course { get; set; }
    }
}
