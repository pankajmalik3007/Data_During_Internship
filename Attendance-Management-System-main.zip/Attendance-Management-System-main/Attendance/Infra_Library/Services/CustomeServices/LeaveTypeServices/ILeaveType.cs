﻿using Domain_Library.ViewModels;
using Domain_Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static Domain_Library.ViewModels.LeaveViewModel;

namespace Infra_Library.Services.CustomeServices.LeaveTypeServices
{
    public interface ILeaveType
    {
        Task<ICollection<LeaveViewModel>> GetAll();
        Task<LeaveViewModel> Get(int Id);
        Leave GetLast();
        Task<bool> Insert(LeaveInsertModel userInsertModel);
        Task<bool> Update(LeaveUpdateModel userUpdateModel);
        Task<bool> Delete(int Id);
        Task<Leave> Find(Expression<Func<Leave, bool>> match);
    }
}
