﻿using Domain_Library;
using Domain_Library.ViewModels;
using Infra_Library.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Infra_Library.Services.CustomeServices.LeaveTypeServices
{
    public class LeaveType : ILeaveType
    {
        private readonly IRepository<Leave> _userType;
        public LeaveType(IRepository<Leave> userType)
        {
            _userType = userType;
        }

        public async Task<bool> Delete(int Id)
        {
            if (Id != null)
            {
                Leave student = await _userType.Get(Id);
                if (student != null)
                {
                    return await _userType.Delete(student);
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public Task<Leave> Find(Expression<Func<Leave, bool>> match)
        {
            return _userType.Find(match);
        }

        public async  Task<LeaveViewModel> Get(int Id)
        {
            var result = await _userType.Get(Id);
            if (result == null)
                return null;
            else
            {
                LeaveViewModel userTypeViewModel = new()
                {
                    Id = result.Id,
                    UserId = result.UserId,
                    leaveType = result.leaveType,
                    LeaveStartDate = result.LeaveStartDate,
                    LeaveEndDate = result.LeaveEndDate,
                    
                };
                return userTypeViewModel;
            }
        }

        public async Task<ICollection<LeaveViewModel>> GetAll()
        {
            ICollection<LeaveViewModel> userTypeViewModels = new List<LeaveViewModel>();
            ICollection<Leave> userTypes = await _userType.GetAll();
            foreach (Leave userType in userTypes)
            {
                LeaveViewModel userTypeView = new()
                {
                    Id = userType.Id,
                    UserId = userType.UserId,
                    leaveType = userType.leaveType,
                    LeaveStartDate = userType.LeaveStartDate,
                    LeaveEndDate = userType.LeaveEndDate,

                };
                userTypeViewModels.Add(userTypeView);
            }
            return userTypeViewModels;
        }

        public Leave GetLast()
        {
            return _userType.GetLast();
        }

        public Task<bool> Insert(LeaveViewModel.LeaveInsertModel userInsertModel)
        {
            Leave userType = new()
            {
              UserId = userInsertModel.UserId,
              leaveType = userInsertModel.leaveType,
              LeaveStartDate = userInsertModel.LeaveStartDate,
              LeaveEndDate = userInsertModel.LeaveEndDate,

            };
            return _userType.Insert(userType);
        }

        public async Task<bool> Update(LeaveViewModel.LeaveUpdateModel userUpdateModel)
        {
            Leave userType = await _userType.Get(userUpdateModel.Id);
            if (userType != null)
            {
               userType.UserId = userUpdateModel.UserId;
                userType.leaveType = userUpdateModel.leaveType;
                userType.LeaveStartDate = userUpdateModel.LeaveStartDate;
                userType.LeaveEndDate = userUpdateModel.LeaveEndDate;

                var result = await _userType.Update(userType);
                return result;
            }
            else
                return false;
        }
    }
}
