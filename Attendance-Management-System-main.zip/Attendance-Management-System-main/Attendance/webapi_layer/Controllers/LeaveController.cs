﻿using Domain_Library.ViewModels;
using Infra_Library.Services.CustomeServices.LeaveTypeServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static Domain_Library.ViewModels.LeaveViewModel;

namespace webapi_layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveController : ControllerBase
    {

        private readonly ILeaveType _serviceUserType;
        public LeaveController(ILeaveType serviceUserType)
        {
            _serviceUserType = serviceUserType;
        }
        [Route("GetAllLeaveType")]
        [HttpGet]
        public async Task<ActionResult<LeaveViewModel>> GetAllLeaveType()
        {
            var result = await _serviceUserType.GetAll();

            if (result == null)
                return BadRequest("No Records Found, Please Try Again After Adding them...!");

            return Ok(result);
        }


        [Route("GetLeaveType")]
        [HttpGet]
        public async Task<ActionResult<LeaveViewModel>> GetLeaveType(int Id)
        {
            if (Id != null)
            {
                var result = await _serviceUserType.GetAll();

                if (result == null)
                    return BadRequest("No Records Found, Please Try Again After Adding them...!");

                return Ok(result);
            }
            else
                return NotFound("Invalid Leave ID, Please Entering a Valid One...!");
        }

        [Route("InsertLeaveType")]
        [HttpPost]
        public async Task<IActionResult> InsertLeaveType(LeaveInsertModel userTypeInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Insert(userTypeInsertModel);
                if (result == true)
                    return Ok("Leave Inserted Successfully...!");
                else
                    return BadRequest("Something Went Wrong, UserType Is Not Inserted, Please Try After Sometime...!");
            }
            else
                return BadRequest("Invalid Leave Information, Please Provide Correct Details for UserType...!");
        }

        [Route("UpdateLeaveType")]
        [HttpPut]
        public async Task<IActionResult> UpdateLeaveType(LeaveUpdateModel userTypeModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Update(userTypeModel);
                if (result == true)
                    return Ok(userTypeModel);
                else
                    return BadRequest("Something went wrong, Please Try again later...!");
            }
            else
                return BadRequest("Invalid Leave Information, Please Provide Correct Details for UserType...!");
        }

        [Route("DeleteLeaveType")]
        [HttpDelete]

        public async Task<IActionResult> DeleteLeaveType(int Id)
        {
            var result = await _serviceUserType.Delete(Id);
            if (result == true)
                return Ok("Leave Deleted Successfully...!");
            else
                return BadRequest("Leave is not deleted, Please Try again later...!");

        }
    }
}
