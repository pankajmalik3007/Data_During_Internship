﻿using Domain_Library.ViewModels;
using Infra_Library.Context;
using Infra_Library.Services.CustomeServices.Attendance_Type;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

namespace webapi_layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceTypeService _serviceUserType;
        private readonly MainDbContext _dbContext;
        public AttendanceController(IAttendanceTypeService serviceUserType , MainDbContext dbContext)
        {
            _serviceUserType = serviceUserType;
            _dbContext = dbContext;

            
        }
        [Route("GetAllAttendanceDetails")]
        [HttpGet]
        public async Task<ActionResult<AttendanceViewModel>> GetAllAttendanceDetails()
        {
            var result = await _serviceUserType.GetAll();

            if (result == null)
                return BadRequest("No Records Found, Please Try Again After Adding them...!");

            return Ok(result);
        }


        [Route("GetAttendanceDetailByID")]
        [HttpGet]
        public async Task<ActionResult<AttendanceViewModel>> GetAttendanceDetailByIDe(int Id)
        {
            if (Id != null)
            {
                var result = await _serviceUserType.Get(Id);

                if (result == null)
                    return BadRequest("No Records Found, Please Try Again After Adding them...!");

                return Ok(result);
            }
            else
                return NotFound("Invalid Attendance ID, Please Entering a Valid One...!");
        }

        [Route("InsertAttendanceType")]
        [HttpPost]
        public async Task<IActionResult> InsertAttendanceType(AttendanceInsertModel userTypeInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Insert(userTypeInsertModel);
                if (result == true)
                    return Ok("Attendance Inserted Successfully...!");
                else
                    return BadRequest("Something Went Wrong, UserType Is Not Inserted, Please Try After Sometime...!");
            }
            else
                return BadRequest("Invalid Attendance Information, Please Provide Correct Details for UserType...!");
        }

        [Route("UpdateAttendanceType")]
        [HttpPut]
        public async Task<IActionResult> UpdateAttendanceType(AttendanceUpdateModel userTypeModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Update(userTypeModel);
                if (result == true)
                    return Ok(userTypeModel);
                else
                    return BadRequest("Something went wrong, Please Try again later...!");
            }
            else
                return BadRequest("Invalid Attendance Information, Please Provide Correct Details for UserType...!");
        }

        [Route("DeleteAttendanceType")]
        [HttpDelete]

        public async Task<IActionResult> DeleteAttendanceType(int Id)
        {
            var result = await _serviceUserType.Delete(Id);
            if (result == true)
                return Ok("Attendance Deleted Successfully...!");
            else
                return BadRequest("Attendance is not deleted, Please Try again later...!");

        }
        [Route("DataById")]
        [HttpGet]
        public async Task<ActionResult<int>> DataById(int userId)
        {
            try
            {
                if (userId <= 0)
                    return BadRequest("Invalid User ID, Please provide a valid ID...!");

                var (loginCount, userDetails, clockInTimes) = await _serviceUserType.GetLoginCountAndUserDetailsByUserId(userId);

                if (loginCount == -1)
                    return BadRequest("User with the specified ID does not exist...!");

                var formattedClockInTimes = clockInTimes?.Select(time => time.ToString("yyyy-MM-dd HH:mm:ss")).ToList();

                return Ok($"User with ID {userId} (Name: {userDetails.Username}, Email: {userDetails.Email}, PhoneNo: {userDetails.PhoneNo}) has logged in {loginCount} times. Clock-in times: {string.Join(", ", formattedClockInTimes)}");
            }
            catch (Exception ex)
            {
              
                Console.WriteLine(ex.Message);
                return StatusCode(500, "Internal Server Error");
            }
        }

        /*  [Route("DataById")]
          [HttpGet]
          public async Task<ActionResult<int>> DataById(int userId)
          {
              if (userId <= 0)
                  return BadRequest("Invalid User ID, Please provide a valid ID...!");

              var user = await _dbContext.Users
                  .Where(u => u.Id == userId)
                  .FirstOrDefaultAsync();

              if (user == null)
                  return BadRequest("User with the specified ID does not exist...!");

              var loginCount = await _dbContext.Attendances
                  .Where(a => a.UserId == userId)  
                  .CountAsync();

              return Ok($"User with ID {userId} (Name: {user.Username}, Email: {user.Email}, PhoneNo: {user.PhoneNo}) has logged in {loginCount} times.");
          }
  */


    }
}
