﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Domain_Library;
using Infra_Library.Context;

[Route("api/[controller]")]
[ApiController]
public class ReportController : ControllerBase
{
    private readonly MainDbContext _context;

    public ReportController(MainDbContext context)
    {
        _context = context;
    }

    [HttpGet("GetAllReports")]
    public async Task<ActionResult<IEnumerable<Report>>> GetAllReports()
    {
        var reports = await _context.Reports.ToListAsync();

        if (reports == null || !reports.Any())
        {
            return NoContent(); 
        }

        return reports;
    }

   

    
    public class ReportDto
    {
        public int UserId { get; set; }
        public int AttendanceId { get; set; }
        public DateTime StartBreakTime { get; set; }
        public DateTime EndBreakTime { get; set; }
        public DateTime CheckOutTime { get; set; }
    }

    
    [HttpPost]
    public async Task<ActionResult<Report>> InsertReport([FromBody] ReportDto reportDto)
    {
        if (ModelState.IsValid)
        {
            var currentTime = DateTime.Now;

            var report = new Report
            {
                UserId = reportDto.UserId,
                AttendanceId = reportDto.AttendanceId,
                StartBreakTime = currentTime,
                EndBreakTime = currentTime,
                CheckOutTime = currentTime
            };

            _context.Reports.Add(report);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetReport), new { id = report.Id }, report);
        }

        return BadRequest(ModelState);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Report>> GetReport(int id)
    {
        var report = await _context.Reports.FindAsync(id);

        if (report == null)
        {
            return NotFound();
        }

        return report;
    }
   
    [HttpGet("CalculateTotalHours/{reportId}")]
    public ActionResult<TimeSpan> CalculateTotalHours(int reportId)
    {
        var report = _context.Reports.Include(r => r.Attendance).FirstOrDefault(r => r.Id == reportId);

        if (report == null || report.Attendance == null)
        {
            return NotFound($"Report with id {reportId} not found.");
        }

      
        TimeSpan totalTime = report.CheckOutTime - report.Attendance.CheckInTime;

        return totalTime;
    }


    [HttpGet("CalculateProductiveHours/{reportId}")]
    public ActionResult<TimeSpan> CalculateProductiveHours(int reportId)
    {
        var report = _context.Reports.Include(r => r.Attendance).FirstOrDefault(r => r.Id == reportId);

        if (report == null || report.Attendance == null)
        {
            return NotFound($"Report with id {reportId} not found or no associated attendance.");
        }

        
        TimeSpan totalTime = report.CheckOutTime - report.Attendance.CheckInTime;

        
        if (report.StartBreakTime != report.EndBreakTime)
        {
            totalTime -= report.EndBreakTime - report.StartBreakTime;
        }

        return totalTime;
    }



    private bool ReportExists(int id)
    {
        return _context.Reports.Any(e => e.Id == id);
    }

}

