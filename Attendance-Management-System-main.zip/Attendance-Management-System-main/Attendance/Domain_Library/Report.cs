﻿using System;
using System.Text.Json.Serialization;

namespace Domain_Library
{
    public class Report : BaseEntity
    {
        public int UserId { get; set; }
        public int AttendanceId { get; set; }

        public DateTime StartBreakTime { get; set; }
        public DateTime EndBreakTime { get; set; }
        public DateTime CheckOutTime { get; set; }

        [JsonIgnore]
        public User User { get; set; }
        public Attendance Attendance { get; set; }
    }
}
