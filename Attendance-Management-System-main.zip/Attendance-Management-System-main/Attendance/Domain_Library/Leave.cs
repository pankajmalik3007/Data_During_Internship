﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain_Library
{
    public class Leave : BaseEntity
    {
        public int UserId { get; set; }
       
        public DateTime LeaveStartDate { get; set; }
        public DateTime LeaveEndDate { get; set; }
        public string leaveType { get; set; }

        [JsonIgnore]
        public User User { get; set; }
    }
}
