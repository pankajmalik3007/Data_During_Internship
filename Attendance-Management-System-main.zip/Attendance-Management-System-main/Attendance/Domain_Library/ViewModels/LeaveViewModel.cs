﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Library.ViewModels
{
    public class LeaveViewModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }

        public DateTime LeaveStartDate { get; set; }
        public DateTime LeaveEndDate { get; set; }
        public string leaveType { get; set; }

/*        public List<UserViewModel> User { get; set; } = new List<UserViewModel>();
*/

        public class LeaveInsertModel
        {
            public int UserId { get; set; }

            public DateTime LeaveStartDate { get; set; }
            public DateTime LeaveEndDate { get; set; }
            public string leaveType { get; set; }
        }

        public class LeaveUpdateModel : LeaveInsertModel
        {
            public int Id { get; set; }

        }

    }
}