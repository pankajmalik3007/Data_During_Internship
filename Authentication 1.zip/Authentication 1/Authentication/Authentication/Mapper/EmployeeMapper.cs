﻿using Authentication.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using OneToMany.Models;

namespace Authentication.Mapper
{
    public class EmployeeMapper : IEntityTypeConfiguration<Employee>
    {

        public void Configure(EntityTypeBuilder<Employee> builder)
        {
            builder.HasKey(e => e.Emp_Id)
                .HasName("pk_Employee_Id");

            builder.Property(e => e.Emp_Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("Employee Id")
                .HasColumnType("INT");

            builder.Property(e => e.Emp_Name)
                .HasColumnName("Employee Name")
                .HasColumnType("Nvarchar(100)")
                .IsRequired();

            builder.Property(e => e.Emp_Adress)
                .HasColumnName("Employee Address")
                .HasColumnType("NVarchar(500)")
                .IsRequired();

            builder.Property(e => e.mobno)
                .HasColumnName("Employee PhNo")
                .HasColumnType("NVarchar(500)")
                .IsRequired();

            builder.Property(e => e.Sallary)
                .HasColumnName("Employee Sallary")
                .HasColumnType("NVarchar(500)")
                .IsRequired();

            builder.Property(e => e.age)
               .HasColumnName("Employee Age")
               .HasColumnType("NVarchar(500)")
               .IsRequired();


            builder.HasOne<Department>(d => d.Department)
               .WithMany(e => e.Employees)
               .HasForeignKey(f => f.Dept_Id)
               .IsRequired();

            builder.HasOne<State>(d => d.State)
                .WithMany(e => e.Employees)
                .HasForeignKey(f => f.StateId)
                .IsRequired();

         /*   builder.HasOne<City>(d => d.City)
                .WithMany(e => e.Employees)
                .HasForeignKey(f => f.CityId)
                .IsRequired();*/
        }

    }
}
