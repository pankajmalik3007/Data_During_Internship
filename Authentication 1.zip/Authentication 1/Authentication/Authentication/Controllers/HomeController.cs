﻿using Authentication.Context;
using Authentication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace Authentication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private MainDbContext Context { get;}

        public HomeController(ILogger<HomeController> logger, MainDbContext _context)
        {
            _logger = logger;
            Context = _context;
        }

        public IActionResult Index()
        {
            //get country list as SelectListItem
            ViewBag.Statements = Context.Statements.ToList().Select(c => new SelectListItem { Value = c.StateId.ToString(), Text = c.StateName }).ToList();
            return View();
        }

        //this method is called using jQuery
        public IActionResult GetCities(int id)
        {
            //get state list as SelectListItem
            var statesList = Context.Cities.Where(s => s.StateId == id).ToList().Select(c => new SelectListItem { Value = c.CityId.ToString(), Text = c.CityName }).ToList();
            return Json(statesList);
        }
        //method where form is posted
        [HttpPost]
        public IActionResult Index(int Country, int State)
        {
            //get selected country/state name
            ViewBag.SelectedStates = Context.Statements.Where(a => a.StateId == Country).FirstOrDefault().StateName;
            ViewBag.SelectedCities = Context.Cities.Where(a => a.CityId == State).FirstOrDefault().CityName;

            //again get country list as SelectListItem 
            ViewBag.Statements = Context.Statements.ToList().Select(c => new SelectListItem { Value = c.StateId.ToString(), Text = c.StateName }).ToList();
            return View();
        }
    }
}