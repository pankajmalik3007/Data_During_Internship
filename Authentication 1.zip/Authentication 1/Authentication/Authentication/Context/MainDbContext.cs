﻿using Authentication.Mapper;
using Authentication.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OneToMany.Models;

namespace Authentication.Context
{
    public class MainDbContext : IdentityDbContext
    {
        public MainDbContext(DbContextOptions<MainDbContext> option) : base(option)
        {

        }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }

        public DbSet<City> Cities { get; set; }
        public DbSet<State> Statements { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new EmployeeMapper());
            base.OnModelCreating(builder);

            builder.ApplyConfiguration(new DepartmentMapper());
            base.OnModelCreating(builder);

            builder.ApplyConfiguration(new StateMapper());
            base.OnModelCreating(builder);

            builder.ApplyConfiguration(new CityMapper());
            base.OnModelCreating(builder);
        }

    }
}
