import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h6>Welcome to the Home Page</h6>
      <p>This is a simple home page for your application.</p>
    </div>
  );
};

export default HomePage;
