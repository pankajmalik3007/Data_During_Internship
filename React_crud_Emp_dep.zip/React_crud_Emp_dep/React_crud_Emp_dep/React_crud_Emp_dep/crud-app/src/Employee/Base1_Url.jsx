export const Base_Url = "https://localhost:44393/";


export const apiExtension = "api/";

export const Get_All_Emp = "Employee/GetAll";
export const Create_Emp = "Employee/Create";
export const Update_Emp = "Employee/Update";
export const Delete_Emp = "Employee/Delete/";