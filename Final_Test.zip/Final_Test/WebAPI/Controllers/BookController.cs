﻿using Domain.View_Models;
using Infrastructure.Services.Custom.BookServices;
using Infrastructure.Services.Custom.UserServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;
        private readonly ILogger<BookController> _logger;

        public BookController(IBookService userService, ILogger<BookController> logger)
        {
            _bookService = userService;
            _logger = logger;
        }

        [HttpGet(nameof(GetAll))]
        public async Task<ActionResult<BookViewModel>> GetAll()
        {
            _logger.LogInformation("Getting All The Records ..... !");
            var result = await _bookService.GetAll();
            if (result == null)
            {
                _logger.LogWarning("Book Records Are Not Found");
                return BadRequest("Book Records Are Not Found");
            }
            return Ok(result);
        }

        [HttpGet(nameof(GetById))]
        public async Task<ActionResult<BookViewModel>> GetById(Guid id)
        {
            _logger.LogInformation("Getting All The Records By Id ..... !");
            var result = await _bookService.GetById(id);
            if (result == null)
            {
                _logger.LogWarning("Book Records Are Not Found");
                return BadRequest("Book Records Are Not Found");
            }
            return Ok(result);
        }

        /*[HttpGet(nameof(GetByName))]
        public async Task<ActionResult<BookViewModel>> GetByName(string name)
        {
            _logger.LogInformation("Getting All The Records By Name..... !");
            var result = await _bookService.GetByName(name);
            if (result == null)
            {
                _logger.LogWarning("Book Records Are Not Found");
                return BadRequest("Book Records Are Not Found");
            }
            return Ok(result);
        }*/

        [HttpPost(nameof(Insert))]
        public async Task<IActionResult> Insert([FromForm] BookInsertModel BookInsertModel)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Inserting Record ...... !");
                var result = await _bookService.Insert(BookInsertModel);
                if (result == true)
                {
                    _logger.LogInformation("Data Inserted Successfully .....!");
                    return Ok("Data Inserted Successfully .....!");
                }
                else
                {
                    _logger.LogWarning("Something Went Wrong .... !");
                    return BadRequest("Something Went Wrong .... !");
                }
            }
            else
            {
                return BadRequest("Model State Is Not Valid ..... !");
            }
        }

        [HttpPut(nameof(Update))]
        public async Task<IActionResult> Update([FromForm] BookUpdateModel BookUpdateModel)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Updating Record ...... !");
                var result = await _bookService.Update(BookUpdateModel);
                if (result == true)
                {
                    _logger.LogInformation("Data Updated Successfully .....!");
                    return Ok("Data Updated Successfully .....!");
                }
                else
                {
                    _logger.LogWarning("Something Went Wrong .... !");
                    return BadRequest("Something Went Wrong .... !");
                }
            }
            else
            {
                return BadRequest("Model State Is Not Valid ..... !");
            }
        }

        [HttpDelete(nameof(Delete))]
        public async Task<IActionResult> Delete(Guid id)
        {
            if (id != Guid.Empty)
            {
                _logger.LogInformation("Deleting Record ...... !");
                var result = await _bookService.Delete(id);
                if (result == true)
                {
                    _logger.LogInformation("Data Deleted Successfully .....!");
                    return Ok("Data Deleted Successfully .....!");
                }
                else
                {
                    _logger.LogWarning("Something Went Wrong .... !");
                    return BadRequest("Something Went Wrong .... !");
                }
            }
            else
            {
                return BadRequest("Model State Is Not Valid ..... !");
            }
        }
    }
}
