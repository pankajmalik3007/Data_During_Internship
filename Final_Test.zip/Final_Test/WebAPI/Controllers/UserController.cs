﻿using Domain.View_Models;
using Infrastructure.Services.Custom.UserServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILogger<UserController> _logger;

        public UserController(IUserService userService, ILogger<UserController> logger)
        {
            _userService = userService;
            _logger = logger;
        }

        [HttpGet(nameof(GetAll))]
        public async Task<ActionResult<UserViewModel>> GetAll()
        {
            _logger.LogInformation("Getting All The Records ..... !");
            var result = await _userService.GetAll();
            if(result == null)
            {
                _logger.LogWarning("User Records Are Not Found");
                return BadRequest("User Records Are Not Found");
            }
            return Ok(result);
        }

        [HttpGet(nameof(GetById))]
        public async Task<ActionResult<UserViewModel>> GetById(Guid id)
        {
            _logger.LogInformation("Getting All The Records By Id ..... !");
            var result = await _userService.GetById(id);
            if (result == null)
            {
                _logger.LogWarning("User Records Are Not Found");
                return BadRequest("User Records Are Not Found");
            }
            return Ok(result);
        }

        /*[HttpGet(nameof(GetByName))]
        public async Task<ActionResult<UserViewModel>> GetByName(string name)
        {
            _logger.LogInformation("Getting All The Records By Name..... !");
            var result = await _userService.GetByName(name);
            if (result == null)
            {
                _logger.LogWarning("User Records Are Not Found");
                return BadRequest("User Records Are Not Found");
            }
            return Ok(result);
        }*/


        /*[HttpGet(nameof(GetByLast))]
        public Task<ActionResult<UserViewModel>> GetByLast()
        {
            var result =  _userService.GetLast();
            if (result == null)
            {
                return false;
            }
            return result;
        }*/

        [HttpPost(nameof(Insert))]
        public async Task<IActionResult> Insert([FromForm] UserInsertModel UserInsertModel)
        {
            if(ModelState.IsValid)
            {
                _logger.LogInformation("Inserting Record ...... !");
                var result = await _userService.Insert(UserInsertModel);
                if(result == true)
                {
                    _logger.LogInformation("Data Inserted Successfully .....!");
                    return Ok("Data Inserted Successfully .....!");
                }
                else
                {
                    _logger.LogWarning("Something Went Wrong .... !");
                    return BadRequest("Something Went Wrong .... !");
                }
            }
            else
            {
                return BadRequest("Model State Is Not Valid ..... !");
            }
        }

        [HttpPut(nameof(Update))]
        public async Task<IActionResult> Update([FromForm] UserUpdateModel UserUpdateModel)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Updating Record ...... !");
                var result = await _userService.Update(UserUpdateModel);
                if (result == true)
                {
                    _logger.LogInformation("Data Updated Successfully .....!");
                    return Ok("Data Updated Successfully .....!");
                }
                else
                {
                    _logger.LogWarning("Something Went Wrong .... !");
                    return BadRequest("Something Went Wrong .... !");
                }
            }
            else
            {
                return BadRequest("Model State Is Not Valid ..... !");
            }
        }

        [HttpDelete(nameof(Delete))]
        public async Task<IActionResult> Delete(Guid id)
        {
            if(id != Guid.Empty)
            {
                _logger.LogInformation("Deleting Record ...... !");
                var result = await _userService.Delete(id);
                if (result == true)
                {
                    _logger.LogInformation("Data Deleted Successfully .....!");
                    return Ok("Data Deleted Successfully .....!");
                }
                else
                {
                    _logger.LogWarning("Something Went Wrong .... !");
                    return BadRequest("Something Went Wrong .... !");
                }
            }
            else
            {
                return BadRequest("Model State Is Not Valid ..... !");
            }
        }
    }
}
