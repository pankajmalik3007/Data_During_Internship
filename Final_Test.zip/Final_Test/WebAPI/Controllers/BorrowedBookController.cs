﻿using Domain.Models;
using Domain.View_Models;
using Infrastructure.Services.Custom.BookServices;
using Infrastructure.Services.Custom.BorrowedBookServices;
using Infrastructure.Services.Custom.UserServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BorrowedBookController : ControllerBase
    {
        private readonly IBorrowedBookService _borrowedBookService;
        private readonly IUserService _userService;
        private readonly IBookService _bookService;
        private readonly ILogger<BorrowedBookController> _logger;

        public BorrowedBookController(IBorrowedBookService borrowedBookService, IUserService userService, IBookService bookService, ILogger<BorrowedBookController> logger)
        {
            _borrowedBookService = borrowedBookService;
            _userService = userService;
            _bookService = bookService;
            _logger = logger;
        }

        [HttpGet(nameof(GetAll))]
        public async Task<ActionResult<BorrowedBookViewModel>> GetAll()
        {
            _logger.LogInformation("Getting All Data ");
            var result = await _borrowedBookService.GetAll();

            if (result == null)
            {
                _logger.LogWarning("Borrowed Book data was Not Found");
                return BadRequest("Borrowed Book data was Not Found");
            }
            return Ok(result);
        }

        [HttpGet(nameof(GetById))]
        public async Task<ActionResult<BorrowedBookViewModel>> GetById(Guid id)
        {
            _logger.LogInformation("Getting Data By Id");
            var result = await _borrowedBookService.GetById(id);

            if (result == null)
            {
                _logger.LogWarning("Borrowed Book data was Not Found");
                return BadRequest("Borrowed Book data was Not Found");
            }
            return Ok(result);
        }

        [HttpPost(nameof(Insert))]
        public async Task<IActionResult> Insert([FromForm]BorrowedBookInsertModel BorrowedBookInsertModel)
        {
            if(ModelState.IsValid)
            {
                User user = await _userService.Find(x => x.Id == BorrowedBookInsertModel.UserID);
                if(user != null)
                {
                    Book book = await _bookService.Find(x => x.Id == BorrowedBookInsertModel.BookID);
                    if(book != null)
                    {
                        var result = await _borrowedBookService.Insert(BorrowedBookInsertModel);
                        if (result == true)
                        {
                            return Ok("Data Inserted Successfuly......!");
                        }
                        else
                            return BadRequest("Something Went Wrong ....!");
                    }
                    else
                        return BadRequest("Book ID Is Not Found ....!");
                }
                else
                    return BadRequest("User ID Is Not Found ....!");
            }
            else
                return BadRequest("Model State Is Not Valid ....!");
        }

        [HttpPut(nameof(Update))]
        public async Task<IActionResult> Update([FromForm]BorrowedBookUpdateModel BorrowedBookUpdateModel)
        {
            if(ModelState.IsValid)
            {
                var result = await _borrowedBookService.Update(BorrowedBookUpdateModel);
                if(result == true)
                {
                    return Ok("Data Updated Successfully ...!");
                }
                else
                    return BadRequest("Something Went Wrong ....!");
            }
            else
                return BadRequest("Model State Is Not Valid ....!");
        }

        [HttpDelete(nameof(Delete))]
        public async Task<IActionResult> Delete(Guid id)
        {
            if(id != Guid.Empty)
            {
                var result = await _borrowedBookService.Delete(id);
                if (result == true)
                {
                    return Ok("Data Updated Successfully ...!");
                }
                else
                    return BadRequest("Something Went Wrong ....!");
            }
            else
                return BadRequest("Model State Is Not Valid ....!");
        }
    }
}
