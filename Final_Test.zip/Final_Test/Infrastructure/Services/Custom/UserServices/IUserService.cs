﻿using Domain.Models;
using Domain.View_Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services.Custom.UserServices
{
    public interface IUserService
    {
        Task<ICollection<UserViewModel>> GetAll();
        Task<UserViewModel> GetById(Guid id);
        Task<UserViewModel> GetByName(string name);
        User GetLast();
        Task<bool> Insert(UserInsertModel userInsertModel );
        Task<bool> Update(UserUpdateModel userUpdateModel);
        Task<bool> Delete(Guid id);
        Task<User> Find(Expression<Func<User, bool>> match);
    }
}
