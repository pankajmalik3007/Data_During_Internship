﻿using Domain.Models;
using Domain.View_Models;
using Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services.Custom.UserServices
{
    public class UserService : IUserService
    {
        #region Private Variables
        private readonly IRepository<User> _user;

        public UserService(IRepository<User> user)
        {
            _user = user;
        }
        #endregion

       
        #region GetAll
        public async Task<ICollection<UserViewModel>> GetAll()
        {
            ICollection<UserViewModel> userViewModels = new List<UserViewModel>();
            ICollection<User> users = await _user.GetAll();

            foreach(User user in users)
            {
                UserViewModel viewModel = new()
                { 
                    Id = user.Id,
                    UserID = user.UserID,
                    Username = user.Username,
                };
                userViewModels.Add(viewModel);
            }
            return userViewModels;
        }
        #endregion

        #region GetById
        public async Task<UserViewModel> GetById(Guid id)
        {
            var user = await _user.GetById(id);
            if(user == null)
            {
                return null;
            }
            else
            {
                UserViewModel viewModel = new()
                {
                    Id = user.Id,
                    UserID = user.UserID,
                    Username = user.Username,
                };
                return viewModel;
            }
        }
        #endregion

        #region GetByName
        public async Task<UserViewModel> GetByName(string name)
        {
            var user = await _user.GetByName(name);
            if (user == null)
            {
                return null;
            }
            else
            {
                UserViewModel viewModel = new()
                {
                    Id = user.Id,
                    UserID = user.UserID,
                    Username = user.Username,
                };
                return viewModel;
            }
        }
        #endregion

        #region GetLast
        public User GetLast()
        {
            return _user.GetLast();
        }
        #endregion

        #region Insert
        public Task<bool> Insert(UserInsertModel userInsertModel)
        {
            User user = new()
            { 
                UserID = userInsertModel.UserID,
                Username = userInsertModel.Username,
            };
            return _user.Insert(user);

        }
        #endregion

        #region Update
        public async Task<bool> Update(UserUpdateModel userUpdateModel)
        {
            var user = await _user.GetById(userUpdateModel.Id);
            if(user != null)
            {
                user.Username = userUpdateModel.Username;

                var result = await _user.Update(user);
                return result;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Delete
        public async Task<bool> Delete(Guid id)
        {
            if (id != Guid.Empty)
            {
                User user = await _user.GetById(id);
                if (user != null)
                {
                    var result = await _user.Delete(user);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
                return false;
        }
        #endregion

        #region Find
        public Task<User> Find(Expression<Func<User, bool>> match)
        {
            return _user.Find(match);
        }
        #endregion


    }
}
